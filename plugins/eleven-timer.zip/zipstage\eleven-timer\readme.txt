=== Eleven Timer ===
Contributors: gafsiabdeldjalil
Tags: hébergement, compte à rebours, alertes, telegram, whatsapp, email, surveillance
Requires at least: 5.0
Tested up to: 7.1
Requires PHP: 7.0
Stable tag: 5.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Surveillance d'abonnement d'hébergement : astrolabe saharien futuriste protégé par mot de passe et alertes automatiques E-mail + Telegram/WhatsApp. Interface bilingue automatique : français ou anglais selon la langue du site.

== Description ==

Eleven Timer surveille la date d'expiration de votre abonnement d'hébergement et vous alerte automatiquement à J-90, J-30, J-15, J-7 puis à l'expiration.

Fonctionnalités :

* Icône discrète « T » en bas à droite du site public (activable/désactivable)
* Accès au timer protégé par mot de passe (vérifié côté serveur, anti force-brute)
* Compte à rebours temps réel dans un astrolabe saharien animé (étoiles, lune, dunes, sable)
* Alertes doublées : e-mail + Telegram (recommandé), WhatsApp CallMeBot ou Cloud API Meta
* Panneau d'administration complet : dates, contacts, passerelles, test d'envoi, journal
* Nœud dans la barre d'administration avec les jours restants
* Vérification quotidienne automatique (cron WordPress)

= Configuration Telegram =

1. Dans Telegram, cherchez @BotFather → /newbot → récupérez le token du bot.
2. Cherchez @userinfobot → récupérez votre Chat Id.
3. Collez token + Chat Id dans ⏳ Eleven Timer → Enregistrer → TEST TELEGRAM.

= Mot de passe par défaut =

Le mot de passe d'accès initial est Eleven1975@ — changez-le dès l'activation dans le panneau du plugin.

== Installation ==

1. Extensions → Ajouter → Téléverser une extension → sélectionnez eleven-timer.zip.
2. Activez le plugin : l'assistant de configuration s'ouvre.
3. Renseignez dates d'abonnement, e-mail et passerelle Telegram/WhatsApp.

== Frequently Asked Questions ==

= Les e-mails n'arrivent pas ? =
Installez un plugin SMTP (ex : WP Mail SMTP) — l'envoi wp_mail des hébergeurs mutualisés est souvent limité.

= Le message Telegram n'arrive pas ? =
Vérifiez le token, le Chat Id, et appuyez sur Démarrer dans la conversation avec votre bot.

== Changelog ==

= 5.0 =
* Interface bilingue automatique FR / EN : tout le plugin (administration, e-mails, Telegram/WhatsApp, widget public) s'affiche en français sur un site en français, en anglais pour toute autre langue — sans aucun réglage
* Sujets d'alertes bilingues (J- devient D- en anglais)

= 4.4 =
* Compatible tout hébergement : aucun chemin codé en dur, PHP 7.0 minimum
* En-têtes Requires at least / Requires PHP

= 4.3 =
* Passerelle Telegram ajoutée (token + Chat ID), recommandée par défaut

= 4.2 =
* Refonte visuelle : astrolabe saharien animé

== Upgrade Notice ==

= 5.0 =
Aucune action requise — la langue s'adapte automatiquement à celle du site.
