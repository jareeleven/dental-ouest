<?php
/*
Plugin Name: Eleven Timer
Plugin URI: https://www.provencetour-dz.com/
Description: Hosting subscription monitoring: discreet "T" icon, password-protected futuristic Saharan astrolabe, doubled E-mail + WhatsApp/Telegram alerts at D-90, D-30, D-15, D-7. Automatic FR/EN bilingual.
Version: 5.0
Requires at least: 5.0
Requires PHP: 7.0
Author: Gafsi Abdeldjalil
Author URI: https://www.provencetour-dz.com/
Text Domain: eleven-timer
*/

if (!defined('ABSPATH')) exit;

define('PTIMER_VERSION', '5.0');
define('PTIMER_DEFAULT_PASSWORD', 'Eleven1975@');

/* ============================================================
   AUTOMATIC FR / EN BILINGUAL
   La langue suit celle du site WordPress (réglages → Général).
   Toute langue autre que française affiche l'anglais.
   ============================================================ */

function pt_lang() {
    return (strpos((string) get_locale(), 'fr') === 0) ? 'fr' : 'en';
}

function pt_t($fr, $en) {
    return pt_lang() === 'fr' ? $fr : $en;
}

/* ============================================================
   1. ACTIVATION / DÉSACTIVATION / DÉSINSTALLATION
   ============================================================ */

function ptimer_activate() {
    if (!get_option('ptimer_password')) {
        add_option('ptimer_password', wp_hash_password(PTIMER_DEFAULT_PASSWORD));
    }
    add_option('ptimer_notified', array());
    add_option('ptimer_setup_done', 0);
    add_option('ptimer_show_frontend', 1);
    add_option('ptimer_admins_only', 0);
    add_option('ptimer_wa_method', 'telegram');
    add_option('ptimer_tg_token', '');
    add_option('ptimer_tg_chat', '');
    add_option('ptimer_setup_redirect', 1);
    if (!wp_next_scheduled('ptimer_daily_check')) {
        wp_schedule_event(strtotime('tomorrow 09:00:00'), 'daily', 'ptimer_daily_check');
    }
}
register_activation_hook(__FILE__, 'ptimer_activate');

function ptimer_deactivate() {
    wp_clear_scheduled_hook('ptimer_daily_check');
}
register_deactivation_hook(__FILE__, 'ptimer_deactivate');

function ptimer_uninstall() {
    $keys = array(
        'ptimer_password', 'ptimer_start_date', 'ptimer_end_date',
        'ptimer_email', 'ptimer_whatsapp', 'ptimer_wa_method',
        'ptimer_wa_token', 'ptimer_wa_phone_id', 'ptimer_wa_apikey',
        'ptimer_tg_token', 'ptimer_tg_chat',
        'ptimer_notified', 'ptimer_setup_done', 'ptimer_show_frontend',
        'ptimer_admins_only', 'ptimer_log', 'ptimer_migrated', 'ptimer_setup_redirect',
    );
    foreach ($keys as $k) {
        delete_option($k);
    }
    delete_transient('ptimer_flash');
    wp_clear_scheduled_hook('ptimer_daily_check');
}
register_uninstall_hook(__FILE__, 'ptimer_uninstall');

/* ============================================================
   2. MIGRATION DEPUIS L'ANCIENNE VERSION DU PLUGIN
   ============================================================ */

function ptimer_migrate_old_options() {
    if (get_option('ptimer_migrated')) return;
    $old = get_option('provencetour_expiration_date');
    if ($old && !get_option('ptimer_end_date')) {
        update_option('ptimer_end_date', $old);
        if (!get_option('ptimer_start_date')) {
            update_option('ptimer_start_date', date('Y-m-d', strtotime($old . ' -1 year')));
        }
    }
    update_option('ptimer_migrated', 1);
}

/* ============================================================
   3. FONCTIONS UTILITAIRES
   ============================================================ */

function ptimer_end_ts() {
    $d = get_option('ptimer_end_date');
    return $d ? strtotime($d . ' 23:59:59') : 0;
}

function ptimer_start_ts() {
    $d = get_option('ptimer_start_date');
    return $d ? strtotime($d . ' 00:00:00') : 0;
}

function ptimer_days_left() {
    $end = ptimer_end_ts();
    if (!$end) return null;
    return (int) floor(($end - time()) / DAY_IN_SECONDS);
}

function ptimer_status($days) {
    if ($days === null) return array('label' => 'NON CONFIGURÉ', 'color' => '#8a8f9f');
    if ($days <= 0)  return array('label' => 'EXPIRÉ',     'color' => '#ff4d4d');
    if ($days <= 7)  return array('label' => 'CRITIQUE',   'color' => '#ff5d5d');
    if ($days <= 30) return array('label' => 'ALERTE',     'color' => '#ffa14a');
    if ($days <= 90) return array('label' => 'ATTENTION',  'color' => '#ffd76a');
    return array('label' => 'OPÉRATIONNEL', 'color' => '#57e389');
}

function ptimer_fmt_date($ts) {
    return $ts ? date_i18n('d/m/Y', $ts) : '—';
}

function ptimer_log($channel, $status) {
    $log = get_option('ptimer_log', array());
    array_unshift($log, array(
        'time'    => current_time('mysql'),
        'channel' => $channel,
        'status'  => $status,
    ));
    update_option('ptimer_log', array_slice($log, 0, 30));
}

function ptimer_flash_set($msg, $type = 'ok') {
    set_transient('ptimer_flash', array('msg' => $msg, 'type' => $type), 120);
}

function ptimer_flash_get() {
    $f = get_transient('ptimer_flash');
    if ($f) delete_transient('ptimer_flash');
    return $f;
}

/* ============================================================
   4. MENU ADMIN + REDIRECTION CONFIGURATION INITIALE
   ============================================================ */

add_action('admin_menu', function () {
    add_menu_page(
        'Eleven Timer',
        '⏳ Eleven Timer',
        'manage_options',
        'eleven_timer',
        'ptimer_render_settings_page',
        'dashicons-clock',
        3
    );
    add_submenu_page(
        'eleven_timer',
        'Configuration initiale',
        'Configuration initiale',
        'manage_options',
        'eleven_timer_setup',
        'ptimer_render_setup_page'
    );
});

add_action('admin_init', function () {
    ptimer_migrate_old_options();

    if (!wp_next_scheduled('ptimer_daily_check')) {
        wp_schedule_event(time() + 300, 'daily', 'ptimer_daily_check');
    }

    if (get_option('ptimer_setup_redirect') && current_user_can('manage_options')) {
        delete_option('ptimer_setup_redirect');
        wp_safe_redirect(admin_url('admin.php?page=eleven_timer_setup'));
        exit;
    }

    ptimer_handle_post_actions();
});

add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;
    if (get_option('ptimer_setup_done')) return;
    $page = isset($_GET['page']) ? $_GET['page'] : '';
    if ($page === 'eleven_timer_setup' || $page === 'eleven_timer') return;
    echo '<div class="notice notice-warning"><p><strong>⏳ Eleven Timer :</strong> ' . esc_html(pt_t("le plugin doit être configuré (dates d'abonnement + contacts de notification).", 'the plugin must be configured (subscription dates + notification contacts).')) . ' ';
    echo '<a href="' . esc_url(admin_url('admin.php?page=eleven_timer_setup')) . '" class="button button-primary" style="margin-left:8px;">' . esc_html(pt_t('Configurer maintenant', 'Configure now')) . '</a></p></div>';
});

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    array_unshift($links, '<a href="' . admin_url('admin.php?page=eleven_timer') . '">' . pt_t('Réglages', 'Settings') . '</a>');
    return $links;
});

/* ============================================================
   5. TRAITEMENT DES FORMULAIRES ADMIN
   ============================================================ */

function ptimer_verify_nonce_field($action) {
    if (!isset($_POST['ptimer_nonce']) || !wp_verify_nonce($_POST['ptimer_nonce'], $action)) {
        wp_die('Vérification de sécurité échouée.');
    }
}

function ptimer_save_settings() {
    $start   = isset($_POST['ptimer_start_date']) ? sanitize_text_field(wp_unslash($_POST['ptimer_start_date'])) : '';
    $end     = isset($_POST['ptimer_end_date']) ? sanitize_text_field(wp_unslash($_POST['ptimer_end_date'])) : '';
    $email   = isset($_POST['ptimer_email']) ? sanitize_email(wp_unslash($_POST['ptimer_email'])) : '';
    $wa      = isset($_POST['ptimer_whatsapp']) ? preg_replace('/[^0-9+]/', '', wp_unslash($_POST['ptimer_whatsapp'])) : '';
    $method  = (isset($_POST['ptimer_wa_method']) && in_array($_POST['ptimer_wa_method'], array('callmebot', 'cloud', 'telegram'), true)) ? $_POST['ptimer_wa_method'] : 'telegram';
    $token   = isset($_POST['ptimer_wa_token']) ? sanitize_text_field(wp_unslash($_POST['ptimer_wa_token'])) : '';
    $pid     = isset($_POST['ptimer_wa_phone_id']) ? sanitize_text_field(wp_unslash($_POST['ptimer_wa_phone_id'])) : '';
    $apikey  = isset($_POST['ptimer_wa_apikey']) ? sanitize_text_field(wp_unslash($_POST['ptimer_wa_apikey'])) : '';
    $tg_tok  = isset($_POST['ptimer_tg_token']) ? sanitize_text_field(wp_unslash($_POST['ptimer_tg_token'])) : '';
    $tg_chat = isset($_POST['ptimer_tg_chat']) ? preg_replace('/[^0-9\-]/', '', wp_unslash($_POST['ptimer_tg_chat'])) : '';
    $showf   = !empty($_POST['ptimer_show_frontend']) ? 1 : 0;
    $admonly = !empty($_POST['ptimer_admins_only']) ? 1 : 0;

    $old_end = get_option('ptimer_end_date');

    update_option('ptimer_start_date', $start ? date('Y-m-d', strtotime($start)) : '');
    update_option('ptimer_end_date', $end ? date('Y-m-d', strtotime($end)) : '');
    update_option('ptimer_email', $email);
    update_option('ptimer_whatsapp', $wa);
    update_option('ptimer_wa_method', $method);
    update_option('ptimer_wa_token', $token);
    update_option('ptimer_wa_phone_id', $pid);
    update_option('ptimer_wa_apikey', $apikey);
    update_option('ptimer_tg_token', $tg_tok);
    update_option('ptimer_tg_chat', $tg_chat);
    update_option('ptimer_show_frontend', $showf);
    update_option('ptimer_admins_only', $admonly);

    $p1 = isset($_POST['ptimer_pass1']) ? wp_unslash($_POST['ptimer_pass1']) : '';
    $p2 = isset($_POST['ptimer_pass2']) ? wp_unslash($_POST['ptimer_pass2']) : '';

    if ($p1 !== '' || $p2 !== '') {
        if ($p1 === $p2 && strlen($p1) >= 6) {
            update_option('ptimer_password', wp_hash_password($p1));
            ptimer_flash_set(pt_t("Mot de passe d'accès mis à jour avec succès.", 'Access password updated successfully.'));
        } else {
            ptimer_flash_set(pt_t('Les mots de passe ne correspondent pas (minimum 6 caractères).', 'Passwords do not match (minimum 6 characters).'), 'err');
        }
    }

    if ($end && date('Y-m-d', strtotime($end)) !== $old_end) {
        update_option('ptimer_notified', array());
        ptimer_log(pt_t('Système', 'System'), pt_t("Nouvelle date d'expiration enregistrée — alertes réinitialisées.", 'New expiration date saved — alerts reset.'));
    }
}

function ptimer_handle_post_actions() {
    if (!is_admin() || !current_user_can('manage_options')) return;
    if (!isset($_POST['ptimer_action'])) return;

    $page = isset($_POST['ptimer_page']) ? sanitize_key($_POST['ptimer_page']) : 'main';
    ptimer_verify_nonce_field('ptimer_' . $page);

    $act = sanitize_key(wp_unslash($_POST['ptimer_action']));
    ptimer_save_settings();

    $redirect = admin_url('admin.php?page=' . ($page === 'setup' ? 'eleven_timer_setup' : 'eleven_timer'));

    if ($act === 'save') {
        if (!empty($_POST['ptimer_finish_setup'])) {
            update_option('ptimer_setup_done', 1);
            ptimer_log(pt_t('Système', 'System'), pt_t('Configuration initiale terminée — surveillance activée.', 'Initial setup complete — monitoring enabled.'));
            wp_safe_redirect(admin_url('admin.php?page=eleven_timer'));
            exit;
        }
        if (!ptimer_flash_get()) ptimer_flash_set(pt_t('Réglages enregistrés avec succès.', 'Settings saved successfully.'));

    } elseif ($act === 'test_email') {
        $body = '<p>' . pt_t("Ceci est un <strong>e-mail de test</strong> du système de surveillance d'hébergement Eleven Timer.", 'This is a <strong>test email</strong> from the Eleven Timer hosting monitoring system.') . '</p>'
              . '<p>' . pt_t("Date d'expiration actuelle :", 'Current expiration date:') . ' <strong>' . esc_html(ptimer_fmt_date(ptimer_end_ts())) . '</strong></p>';
        $res = ptimer_send_email(pt_t('🔔 TEST — Eleven Timer', '🔔 TEST — Eleven Timer'), $body);
        ptimer_flash_set($res === true ? pt_t('E-mail de test envoyé avec succès.', 'Test email sent successfully.') : pt_t("Échec de l'envoi e-mail : ", 'Email sending failed: ') . $res, $res === true ? 'ok' : 'err');

    } elseif ($act === 'test_whatsapp') {
        $msg = pt_t("🔔 TEST Eleven Timer\n\nMessage de test du systeme de surveillance d'hebergement.\nDate d'expiration : ",
                    "🔔 Eleven Timer TEST\n\nTest message from the hosting monitoring system.\nExpiration date: ") . ptimer_fmt_date(ptimer_end_ts());
        $res = ptimer_send_whatsapp($msg);
        $canal = get_option('ptimer_wa_method', 'telegram') === 'telegram'
            ? pt_t('Telegram', 'Telegram')
            : pt_t('WhatsApp', 'WhatsApp');
        ptimer_flash_set($res === true
            ? sprintf(pt_t('%s de test envoyé avec succès.', '%s test message sent successfully.'), $canal)
            : sprintf(pt_t('Échec envoi %s : ', '%s sending failed: '), $canal) . $res,
            $res === true ? 'ok' : 'err');

    } elseif ($act === 'run_check') {
        ptimer_run_daily_check();
        ptimer_flash_set(pt_t('Vérification effectuée — consultez le journal des envois ci-dessous.', 'Check completed — see the sending log below.'));

    } elseif ($act === 'reset_flags') {
        update_option('ptimer_notified', array());
        ptimer_log(pt_t('Système', 'System'), pt_t('Historique des alertes réinitialisé manuellement.', 'Alert history reset manually.'));
        ptimer_flash_set(pt_t('Historique des alertes réinitialisé — les rappels seront renvoyés aux prochaines échéances.', 'Alert history reset — reminders will be sent again at the next thresholds.'));
    }

    wp_safe_redirect($redirect);
    exit;
}

/* ============================================================
   6. ENVOI DES NOTIFICATIONS (E-MAIL + WHATSAPP)
   ============================================================ */

function ptimer_email_template($title, $body) {
    $site = get_bloginfo('name');
    $url  = home_url();
    return '<!DOCTYPE html><html><body style="margin:0;padding:24px;background:#0b0e1f;font-family:Arial,Helvetica,sans-serif;">'
        . '<div style="max-width:560px;margin:0 auto;background:#12162b;border:1px solid #caa23f;border-radius:14px;overflow:hidden;">'
        . '<div style="background:linear-gradient(135deg,#1a1f3d,#2c2f48);padding:20px 26px;border-bottom:1px solid #caa23f;">'
        . '<div style="color:#e8c96a;font-size:11px;letter-spacing:2px;">ELEVEN TIMER • ' . esc_html(pt_t('SYSTÈME DE SURVEILLANCE', 'MONITORING SYSTEM')) . '</div>'
        . '<h1 style="color:#ffffff;font-size:19px;margin:8px 0 0;">' . esc_html($title) . '</h1></div>'
        . '<div style="padding:24px 26px;color:#d7dbe8;font-size:14px;line-height:1.7;">' . $body . '</div>'
        . '<div style="padding:16px 26px;background:#0b0e1f;color:#8a8f9f;font-size:11px;border-top:1px solid #262b45;">'
        . pt_t('Site surveillé : ', 'Monitored site: ') . esc_html($url) . ' — ' . esc_html($site) . '<br>'
        . pt_t('Message automatique, merci de ne pas répondre.', 'Automatic message — please do not reply.') . '</div>'
        . '</div></body></html>';
}

function ptimer_send_email($subject, $html_body) {
    $to = get_option('ptimer_email');
    if (!$to || !is_email($to)) {
        ptimer_log(pt_t('E-mail', 'Email'), pt_t('ÉCHEC — adresse e-mail invalide ou manquante.', 'FAILED — email address invalid or missing.'));
        return pt_t('adresse e-mail invalide ou manquante.', 'email address invalid or missing.');
    }
    $headers = array('Content-Type: text/html; charset=UTF-8');
    $ok = wp_mail($to, $subject, ptimer_email_template($subject, $html_body), $headers);
    if ($ok) {
        ptimer_log(pt_t('E-mail', 'Email'), pt_t('Envoyé à ', 'Sent to ') . $to . ' — ' . $subject);
        return true;
    }
    ptimer_log(pt_t('E-mail', 'Email'), pt_t('ÉCHEC envoi à ', 'FAILED sending to ') . $to . ' — ' . $subject);
    return pt_t("l'envoi WordPress a échoué (vérifiez la configuration SMTP du site).", "WordPress sending failed (check the site SMTP configuration).");
}

function ptimer_send_whatsapp($message) {
    $method = get_option('ptimer_wa_method', 'telegram');

    if ($method === 'telegram') {
        return ptimer_send_telegram($message);
    }

    $to = preg_replace('/[^0-9+]/', '', (string) get_option('ptimer_whatsapp'));
    if (!$to) {
        ptimer_log(pt_t('WhatsApp', 'WhatsApp'), pt_t('ÉCHEC — numéro WhatsApp manquant.', 'FAILED — WhatsApp number missing.'));
        return pt_t('numéro WhatsApp manquant.', 'WhatsApp number missing.');
    }

    if ($method === 'cloud') {
        $token   = get_option('ptimer_wa_token');
        $phoneid = get_option('ptimer_wa_phone_id');
        if (!$token || !$phoneid) {
            ptimer_log(pt_t('WhatsApp', 'WhatsApp'), pt_t('ÉCHEC — configuration Cloud API incomplète.', 'FAILED — Cloud API configuration incomplete.'));
            return pt_t('configuration Cloud API incomplète (token + Phone Number ID requis).', 'Cloud API configuration incomplete (token + Phone Number ID required).');
        }
        $response = wp_remote_post('https://graph.facebook.com/v19.0/' . rawurlencode($phoneid) . '/messages', array(
            'timeout' => 20,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode(array(
                'messaging_product' => 'whatsapp',
                'to'   => ltrim($to, '+'),
                'type' => 'text',
                'text' => array('preview_url' => false, 'body' => $message),
            )),
        ));
    } else {
        $apikey = get_option('ptimer_wa_apikey');
        if (!$apikey) {
            ptimer_log(pt_t('WhatsApp', 'WhatsApp'), pt_t('ÉCHEC — clé API CallMeBot manquante.', 'FAILED — CallMeBot API key missing.'));
            return pt_t('clé API CallMeBot manquante.', 'CallMeBot API key missing.');
        }
        $url = 'https://api.callmebot.com/whatsapp.php?phone=' . urlencode($to)
             . '&text=' . urlencode($message)
             . '&apikey=' . urlencode($apikey);
        $response = wp_remote_get($url, array('timeout' => 20));
    }

    if (is_wp_error($response)) {
        ptimer_log(pt_t('WhatsApp', 'WhatsApp'), pt_t('ÉCHEC — ', 'FAILED — ') . $response->get_error_message());
        return $response->get_error_message();
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    if ($code >= 200 && $code < 300) {
        ptimer_log(pt_t('WhatsApp', 'WhatsApp'), pt_t('Envoyé au ', 'Sent to ') . $to . ' (HTTP ' . $code . ')');
        return true;
    }
    ptimer_log(pt_t('WhatsApp', 'WhatsApp'), pt_t('ÉCHEC — réponse HTTP ', 'FAILED — HTTP response ') . $code);
    return pt_t('réponse HTTP ', 'HTTP response ') . $code . pt_t(' de la passerelle WhatsApp.', ' from the WhatsApp gateway.');
}

function ptimer_send_telegram($message) {
    $token = trim((string) get_option('ptimer_tg_token'));
    $chat  = trim((string) get_option('ptimer_tg_chat'));

    if (!$token || !$chat) {
        ptimer_log('Telegram', pt_t('ÉCHEC — configuration Telegram incomplète (token + Chat ID requis).', 'FAILED — Telegram configuration incomplete (token + Chat ID required).'));
        return pt_t('configuration Telegram incomplète (token du bot + Chat ID requis).', 'Telegram configuration incomplete (bot token + Chat ID required).');
    }

    $response = wp_remote_post('https://api.telegram.org/bot' . rawurlencode($token) . '/sendMessage', array(
        'timeout' => 20,
        'body'    => array(
            'chat_id' => $chat,
            'text'    => $message,
        ),
    ));

    if (is_wp_error($response)) {
        ptimer_log('Telegram', pt_t('ÉCHEC — ', 'FAILED — ') . $response->get_error_message());
        return $response->get_error_message();
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($code >= 200 && $code < 300 && !empty($body['ok'])) {
        ptimer_log('Telegram', pt_t('Envoyé au chat ', 'Sent to chat ') . $chat . ' (HTTP ' . $code . ')');
        return true;
    }

    $desc = isset($body['description']) ? $body['description'] : pt_t('réponse HTTP ', 'HTTP response ') . $code;
    ptimer_log('Telegram', pt_t('ÉCHEC — ', 'FAILED — ') . $desc);
    return pt_t('erreur Telegram : ', 'Telegram error: ') . $desc;
}

/* ============================================================
   7. VÉRIFICATION QUOTIDIENNE + ALERTES J-90 / J-30 / J-15 / J-7
   ============================================================ */

add_action('ptimer_daily_check', 'ptimer_run_daily_check');

function ptimer_run_daily_check() {
    $days = ptimer_days_left();
    if ($days === null) return;

    $thresholds = array(90, 30, 15, 7, 0);
    $notified   = get_option('ptimer_notified', array());

    foreach ($thresholds as $t) {
        if ($days <= $t && empty($notified[$t])) {
            ptimer_dispatch_alert($t, $days);
            $notified[$t] = current_time('mysql');
            update_option('ptimer_notified', $notified);
        }
    }
}

function ptimer_dispatch_alert($threshold, $days) {
    $titles = array(
        90 => pt_t('Rappel — renouvellement dans 3 mois', 'Reminder — renewal in 3 months'),
        30 => pt_t('Alerte — renouvellement dans 1 mois', 'Alert — renewal in 1 month'),
        15 => pt_t('Alerte — renouvellement dans 15 jours', 'Alert — renewal in 15 days'),
        7  => pt_t('URGENT — renouvellement dans 1 semaine', 'URGENT — renewal in 1 week'),
        0  => pt_t('ALERTE ROUGE — hébergement expiré', 'RED ALERT — hosting expired'),
    );
    $title = isset($titles[$threshold]) ? $titles[$threshold] : pt_t('Notification hébergement', 'Hosting notification');

    $end  = ptimer_fmt_date(ptimer_end_ts());
    $site = get_bloginfo('name');
    $j    = max(0, $days);

    $txt = pt_t("🛰️ ELEVEN TIMER — SURVEILLANCE HEBERGEMENT\n\n", "🛰️ ELEVEN TIMER — HOSTING MONITORING\n\n")
         . $title . "\n\n"
         . pt_t('Site : ', 'Site: ') . $site . "\n"
         . pt_t("Date d'expiration : ", 'Expiration date: ') . $end . "\n"
         . pt_t('Temps restant : ', 'Time remaining: ') . $j . pt_t(" jour(s)\n\n", " day(s)\n\n")
         . pt_t("Pensez à renouveler votre abonnement d'hebergement.", 'Please remember to renew your hosting subscription.');

    $html = '<p style="font-size:16px;color:#e8c96a;margin:0 0 14px;"><strong>' . esc_html($title) . '</strong></p>'
          . '<p>' . pt_t('Site : ', 'Site: ') . '<strong>' . esc_html($site) . '</strong></p>'
          . "<p>" . pt_t("Date d'expiration : ", 'Expiration date: ') . '<strong>' . esc_html($end) . '</strong></p>'
          . '<p>' . pt_t('Temps restant estimé : ', 'Estimated time remaining: ') . '<strong>' . $j . pt_t(' jour(s)', ' day(s)') . '</strong></p>'
          . '<p style="margin-top:16px;">' . pt_t("Pensez à renouveler votre abonnement d'hébergement dès que possible.", 'Please renew your hosting subscription as soon as possible.') . '</p>';

    $subject = pt_t('⏳ [Eleven Timer] ', '⏳ [Eleven Timer] ') . $title . ($j > 0 ? (pt_t(' — J-', ' — D-') . $j) : '');
    ptimer_send_email($subject, $html);
    ptimer_send_whatsapp($txt);
}

/* ============================================================
   8. BARRE D'ADMINISTRATION WP (JOURS RESTANTS)
   ============================================================ */

add_action('admin_bar_menu', function ($bar) {
    if (!current_user_can('manage_options')) return;
    $days = ptimer_days_left();
    if ($days === null) return;
    $st = ptimer_status($days);
    $label = $days > 0 ? '⏳ ' . $days . ' ' . pt_t('j', 'd') : '⚠ ' . pt_t('Expiré', 'Expired');
    $bar->add_node(array(
        'id'    => 'ptimer-node',
        'title' => '<span style="color:' . esc_attr($st['color']) . ';font-weight:bold;">' . esc_html($label) . '</span>',
        'href'  => admin_url('admin.php?page=eleven_timer'),
        'meta'  => array('title' => 'Eleven Timer — ' . $st['label']),
    ));
}, 100);

/* ============================================================
   9. PAGE RÉGLAGES PRINCIPALE
   ============================================================ */

function ptimer_admin_styles() {
    echo '<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&display=swap" rel="stylesheet">';
    echo '<style>
    .ptw{max-width:1080px;}
    .ptw-card{background:#12162b;border:1px solid #2a3153;border-radius:14px;padding:22px 24px;margin-top:18px;color:#d7dbe8;}
    .ptw-card h2{margin:0 0 4px;color:#e8c96a;font-size:14px;letter-spacing:1px;text-transform:uppercase;font-family:"Orbitron",sans-serif;}
    .ptw-card .desc{color:#8fa3c8;font-size:12px;margin:0 0 16px;}
    .ptw-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px;}
    .ptw-field label{display:block;font-size:10px;letter-spacing:1px;color:#9aa6c4;margin-bottom:6px;text-transform:uppercase;}
    .ptw-field input[type=date],.ptw-field input[type=text],.ptw-field input[type=email],.ptw-field input[type=password],.ptw-field select{width:100%;background:#0b0e1f;border:1px solid #2c3560;border-radius:8px;padding:10px 12px;color:#fff;font-size:13px;box-sizing:border-box;}
    .ptw-field input:focus,.ptw-field select:focus{border-color:#e8c96a;outline:none;box-shadow:0 0 0 2px rgba(232,201,106,.15);}
    .ptw-check{display:flex;align-items:center;gap:8px;font-size:12px;color:#c7cfe4;margin-top:4px;}
    .ptw-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px;}
    .btn-pt{cursor:pointer;border-radius:8px;padding:11px 20px;font-size:12px;font-weight:700;letter-spacing:1px;border:1px solid transparent;transition:.25s;}
    .btn-pt.primary{background:linear-gradient(135deg,#caa23f,#a47b3b);color:#141414;}
    .btn-pt.primary:hover{filter:brightness(1.12);box-shadow:0 0 14px rgba(232,201,106,.45);}
    .btn-pt.ghost{background:transparent;border-color:#3a4370;color:#bcd0ff;}
    .btn-pt.ghost:hover{border-color:#e8c96a;color:#e8c96a;}
    .btn-pt.danger{background:transparent;border-color:#7a3030;color:#ff8f8f;}
    .btn-pt.danger:hover{border-color:#ff5d5d;color:#ff5d5d;}
    .ptw-flash{margin-top:16px;padding:12px 16px;border-radius:10px;font-size:13px;}
    .ptw-flash.ok{background:#0f2a1c;border:1px solid #2e7d4f;color:#9fe6bd;}
    .ptw-flash.err{background:#2a1214;border:1px solid #7a3030;color:#ffb3b3;}
    .ptw-log{width:100%;border-collapse:collapse;font-size:12px;}
    .ptw-log th,.ptw-log td{padding:8px 10px;border-bottom:1px solid #232a4a;text-align:left;}
    .ptw-log th{color:#8fa3c8;font-weight:600;font-size:10px;letter-spacing:1px;text-transform:uppercase;}
    .ptw-hero{display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;}
    .ptw-count{display:flex;gap:8px;flex-wrap:wrap;}
    .ptw-count .u{background:#0b0e1f;border:1px solid #2c3560;border-radius:10px;padding:10px 14px;text-align:center;min-width:64px;}
    .ptw-count .u b{display:block;font-size:24px;color:#eaf6ff;font-family:Consolas,monospace;}
    .ptw-count .u span{font-size:9px;letter-spacing:2px;color:#8fa3c8;}
    .ptw-pill{padding:5px 14px;border-radius:999px;font-size:11px;letter-spacing:2px;border:1px solid currentColor;font-weight:700;display:inline-block;}
    .ptw-hint{font-size:11px;color:#8fa3c8;line-height:1.7;background:#0b0e1f;border:1px dashed #2c3560;border-radius:8px;padding:10px 14px;margin-top:12px;}
    </style>';
}

function ptimer_render_settings_page() {
    if (!current_user_can('manage_options')) return;

    $flash      = ptimer_flash_get();
    $start      = get_option('ptimer_start_date', '');
    $end        = get_option('ptimer_end_date', '');
    $email      = get_option('ptimer_email', get_option('admin_email'));
    $wa         = get_option('ptimer_whatsapp', '');
    $method     = get_option('ptimer_wa_method', 'telegram');
    $token      = get_option('ptimer_wa_token', '');
    $pid        = get_option('ptimer_wa_phone_id', '');
    $apikey     = get_option('ptimer_wa_apikey', '');
    $tg_token   = get_option('ptimer_tg_token', '');
    $tg_chat    = get_option('ptimer_tg_chat', '');
    $showf      = (int) get_option('ptimer_show_frontend', 1);
    $admonly    = (int) get_option('ptimer_admins_only', 0);
    $log        = get_option('ptimer_log', array());
    $days       = ptimer_days_left();
    $st         = ptimer_status($days);
    $notified   = get_option('ptimer_notified', array());

    ptimer_admin_styles();
    ?>
    <div class="wrap ptw">
        <h1 style="color:#e8c96a;font-family:'Orbitron',sans-serif;">🕰️ ELEVEN TIMER — <?php echo esc_html(pt_t('SURVEILLANCE HÉBERGEMENT', 'HOSTING MONITORING')); ?></h1>

        <?php if ($flash) : ?>
            <div class="ptw-flash <?php echo esc_attr($flash['type']); ?>"><?php echo esc_html($flash['msg']); ?></div>
        <?php endif; ?>

        <div class="ptw-card">
            <h2><?php echo esc_html(pt_t("État de l'abonnement", 'Subscription status')); ?></h2>
            <p class="desc"><?php echo esc_html(pt_t('Compte à rebours en temps réel de votre hébergement.', 'Real-time countdown of your hosting.')); ?></p>
            <div class="ptw-hero">
                <div>
                    <span class="ptw-pill" style="color:<?php echo esc_attr($st['color']); ?>;"><?php echo esc_html($st['label']); ?></span>
                    <p style="margin:12px 0 0;font-size:12px;color:#8fa3c8;">
                        <?php echo esc_html(pt_t('Début : ', 'Start: ')); ?><strong style="color:#c7cfe4;"><?php echo esc_html(ptimer_fmt_date(ptimer_start_ts())); ?></strong>
                        &nbsp;•&nbsp; <?php echo esc_html(pt_t('Fin : ', 'End: ')); ?><strong style="color:#c7cfe4;"><?php echo esc_html(ptimer_fmt_date(ptimer_end_ts())); ?></strong>
                    </p>
                </div>
                <div class="ptw-count" id="ptw-live" data-end="<?php echo esc_attr(ptimer_end_ts()); ?>">
                    <div class="u"><b id="ptw-d">--</b><span><?php echo esc_html(pt_t('JOURS', 'DAYS')); ?></span></div>
                    <div class="u"><b id="ptw-h">--</b><span><?php echo esc_html(pt_t('HEURES', 'HOURS')); ?></span></div>
                    <div class="u"><b id="ptw-m">--</b><span><?php echo esc_html(pt_t('MINUTES', 'MINUTES')); ?></span></div>
                    <div class="u"><b id="ptw-s">--</b><span><?php echo esc_html(pt_t('SECONDES', 'SECONDS')); ?></span></div>
                </div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('ptimer_main', 'ptimer_nonce'); ?>
            <input type="hidden" name="ptimer_page" value="main">

            <div class="ptw-card">
                <h2><?php echo esc_html(pt_t("Dates d'abonnement", 'Subscription dates')); ?></h2>
                <p class="desc"><?php echo esc_html(pt_t('Période couverte par votre hébergement actuel.', 'Period covered by your current hosting.')); ?></p>
                <div class="ptw-grid">
                    <div class="ptw-field">
                        <label><?php echo esc_html(pt_t("Début de l'abonnement", 'Subscription start')); ?></label>
                        <input type="date" name="ptimer_start_date" value="<?php echo esc_attr($start); ?>">
                    </div>
                    <div class="ptw-field">
                        <label><?php echo esc_html(pt_t("Fin de l'abonnement (expiration)", 'Subscription end (expiration)')); ?></label>
                        <input type="date" name="ptimer_end_date" value="<?php echo esc_attr($end); ?>" required>
                    </div>
                </div>
            </div>

            <div class="ptw-card">
                <h2><?php echo esc_html(pt_t('Notifications — rappels J-90, J-30, J-15, J-7', 'Notifications — reminders D-90, D-30, D-15, D-7')); ?></h2>
                <p class="desc"><?php echo esc_html(pt_t('Chaque rappel est envoyé en double : e-mail + Telegram/WhatsApp.', 'Each reminder is sent twice: email + Telegram/WhatsApp.')); ?></p>
                <div class="ptw-grid">
                    <div class="ptw-field">
                        <label><?php echo esc_html(pt_t('E-mail de notification', 'Notification email')); ?></label>
                        <input type="email" name="ptimer_email" value="<?php echo esc_attr($email); ?>">
                    </div>
                    <div class="ptw-field">
                        <label><?php echo esc_html(pt_t('Numéro WhatsApp (format international, ex : +213xxxxxxxxx)', 'WhatsApp number (international format, e.g. +12125550000)')); ?></label>
                        <input type="text" name="ptimer_whatsapp" value="<?php echo esc_attr($wa); ?>" placeholder="+12125550000">
                    </div>
                    <div class="ptw-field">
                        <label><?php echo esc_html(pt_t('Passerelle de notification', 'Notification gateway')); ?></label>
                        <select name="ptimer_wa_method" id="ptw-method">
                            <option value="telegram" <?php selected($method, 'telegram'); ?>><?php echo esc_html(pt_t('Telegram (gratuit, recommandé)', 'Telegram (free, recommended)')); ?></option>
                            <option value="callmebot" <?php selected($method, 'callmebot'); ?>><?php echo esc_html(pt_t('WhatsApp via CallMeBot (gratuit)', 'WhatsApp via CallMeBot (free)')); ?></option>
                            <option value="cloud" <?php selected($method, 'cloud'); ?>><?php echo esc_html(pt_t('WhatsApp Cloud API (Meta, officiel)', 'WhatsApp Cloud API (Meta, official)')); ?></option>
                        </select>
                    </div>
                </div>

                <div id="ptw-telegram-fields" style="margin-top:14px;">
                    <div class="ptw-grid">
                        <div class="ptw-field">
                            <label><?php echo esc_html(pt_t('Token du bot Telegram', 'Telegram bot token')); ?></label>
                            <input type="text" name="ptimer_tg_token" value="<?php echo esc_attr($tg_token); ?>" placeholder="<?php echo esc_attr(pt_t('ex : 7123456789:AAHx...', 'e.g. 7123456789:AAHx...')); ?>">
                        </div>
                        <div class="ptw-field">
                            <label>Chat ID</label>
                            <input type="text" name="ptimer_tg_chat" value="<?php echo esc_attr($tg_chat); ?>" placeholder="<?php echo esc_attr(pt_t('ex : 771062122', 'e.g. 771062122')); ?>">
                        </div>
                    </div>
                    <div class="ptw-hint">
                        📨 <strong><?php echo esc_html(pt_t('Créer votre bot Telegram (2 minutes) :', 'Create your Telegram bot (2 minutes):')); ?></strong><br>
                        1. <?php echo wp_kses_post(pt_t("Dans Telegram, cherchez <strong>@BotFather</strong> → envoyez <code>/newbot</code> → choisissez un nom puis un identifiant se terminant par <em>_bot</em>.", "In Telegram, search for <strong>@BotFather</strong> → send <code>/newbot</code> → choose a name then a username ending in <em>_bot</em>.")); ?><br>
                        2. <?php echo wp_kses_post(pt_t('BotFather vous donne un <strong>token</strong> (ex : <code>7123456789:AAHx…</code>) → copiez-le ci-dessus.', 'BotFather gives you a <strong>token</strong> (e.g. <code>7123456789:AAHx…</code>) → copy it above.')); ?><br>
                        3. <?php echo wp_kses_post(pt_t("Cherchez <strong>@userinfobot</strong> → il affiche votre <strong>Chat Id</strong> → copiez-le ci-dessus.", "Search for <strong>@userinfobot</strong> → it shows your <strong>Chat ID</strong> → copy it above.")); ?><br>
                        4. <?php echo wp_kses_post(pt_t("Important : ouvrez la conversation avec votre nouveau bot et appuyez sur <strong>Démarrer</strong>.", "Important: open the conversation with your new bot and press <strong>Start</strong>.")); ?>
                    </div>
                </div>

                <div id="ptw-callmebot-fields" style="margin-top:14px;">
                    <div class="ptw-grid">
                        <div class="ptw-field">
                            <label><?php echo esc_html(pt_t('Clé API CallMeBot', 'CallMeBot API key')); ?></label>
                            <input type="text" name="ptimer_wa_apikey" value="<?php echo esc_attr($apikey); ?>" placeholder="<?php echo esc_attr(pt_t('ex : 123456', 'e.g. 123456')); ?>">
                        </div>
                    </div>
                    <div class="ptw-hint">
                        📲 <strong><?php echo esc_html(pt_t('Obtenir une clé CallMeBot gratuitement :', 'Get a free CallMeBot key:')); ?></strong>
                        <?php echo wp_kses_post(pt_t("ajoutez le numéro <strong>+34 644 51 95 23</strong> dans vos contacts WhatsApp, envoyez-lui le message", "add the number <strong>+34 644 51 95 23</strong> to your WhatsApp contacts, send it the message")); ?>
                        <em>"I allow callmebot to send me messages"</em>,
                        <?php echo esc_html(pt_t('puis copiez la clé API reçue en réponse.', 'then copy the API key received in reply.')); ?>
                    </div>
                </div>

                <div id="ptw-cloud-fields" style="margin-top:14px;">
                    <div class="ptw-grid">
                        <div class="ptw-field">
                            <label>Access Token (Meta)</label>
                            <input type="text" name="ptimer_wa_token" value="<?php echo esc_attr($token); ?>" placeholder="EAAG...">
                        </div>
                        <div class="ptw-field">
                            <label>Phone Number ID (Meta)</label>
                            <input type="text" name="ptimer_wa_phone_id" value="<?php echo esc_attr($pid); ?>" placeholder="1234567890">
                        </div>
                    </div>
                    <div class="ptw-hint">
                        🔐 <?php echo esc_html(pt_t("Nécessite une application Meta WhatsApp Cloud API (business). Le numéro destinataire doit avoir accepté la conversation.", "Requires a Meta WhatsApp Cloud API (business) app. The recipient number must have accepted the conversation.")); ?>
                    </div>
                </div>
            </div>

            <div class="ptw-card">
                <h2><?php echo esc_html(pt_t('Affichage &amp; sécurité', 'Display &amp; security')); ?></h2>
                <p class="desc"><?php echo esc_html(pt_t("Contrôle de l'icône publique et du mot de passe d'accès au timer.", "Control of the public icon and of the timer access password.")); ?></p>
                <div class="ptw-grid">
                    <div>
                        <label class="ptw-check"><input type="checkbox" name="ptimer_show_frontend" value="1" <?php checked($showf, 1); ?>> <?php echo esc_html(pt_t('Afficher l\'icône « T » sur le site public', 'Show the “T” icon on the public site')); ?></label>
                        <label class="ptw-check"><input type="checkbox" name="ptimer_admins_only" value="1" <?php checked($admonly, 1); ?>> <?php echo esc_html(pt_t("Réserver l'icône aux administrateurs connectés", 'Restrict the icon to logged-in administrators')); ?></label>
                    </div>
                    <div class="ptw-grid">
                        <div class="ptw-field">
                            <label><?php echo esc_html(pt_t('Nouveau mot de passe (laisser vide = inchangé)', 'New password (leave empty = unchanged)')); ?></label>
                            <input type="password" name="ptimer_pass1" autocomplete="new-password">
                        </div>
                        <div class="ptw-field">
                            <label><?php echo esc_html(pt_t('Confirmer le mot de passe', 'Confirm password')); ?></label>
                            <input type="password" name="ptimer_pass2" autocomplete="new-password">
                        </div>
                    </div>
                </div>
            </div>

            <div class="ptw-actions">
                <button type="submit" name="ptimer_action" value="save" class="btn-pt primary">💾 <?php echo esc_html(pt_t('ENREGISTRER LES RÉGLAGES', 'SAVE SETTINGS')); ?></button>
                <button type="submit" name="ptimer_action" value="test_email" class="btn-pt ghost">✉️ <?php echo esc_html(pt_t('TEST E-MAIL', 'EMAIL TEST')); ?></button>
                <button type="submit" name="ptimer_action" value="test_whatsapp" class="btn-pt ghost">📱 <?php echo esc_html(pt_t('TEST WHATSAPP / TELEGRAM', 'WHATSAPP / TELEGRAM TEST')); ?></button>
                <button type="submit" name="ptimer_action" value="run_check" class="btn-pt ghost">▶️ <?php echo esc_html(pt_t('VÉRIFIER MAINTENANT', 'CHECK NOW')); ?></button>
                <button type="submit" name="ptimer_action" value="reset_flags" class="btn-pt danger">♻️ <?php echo esc_html(pt_t('RÉINITIALISER LES ALERTES', 'RESET ALERTS')); ?></button>
            </div>
        </form>

        <div class="ptw-card">
            <h2><?php echo esc_html(pt_t('Journal des envois', 'Delivery log')); ?></h2>
            <p class="desc"><?php echo esc_html(pt_t('Historique des alertes et tests (30 derniers événements).', 'History of alerts and tests (last 30 events).')); ?></p>
            <?php if (empty($log)) : ?>
                <p style="font-size:12px;color:#8fa3c8;"><?php echo esc_html(pt_t('Aucun événement pour le moment.', 'No events yet.')); ?></p>
            <?php else : ?>
                <table class="ptw-log">
                    <thead><tr><th><?php echo esc_html(pt_t('Date', 'Date')); ?></th><th><?php echo esc_html(pt_t('Canal', 'Channel')); ?></th><th><?php echo esc_html(pt_t('Détail', 'Detail')); ?></th></tr></thead>
                    <tbody>
                    <?php foreach ($log as $entry) : ?>
                        <tr>
                            <td style="white-space:nowrap;color:#8fa3c8;"><?php echo esc_html(date_i18n('d/m/Y H:i', strtotime($entry['time']))); ?></td>
                            <td style="white-space:nowrap;color:#e8c96a;"><?php echo esc_html($entry['channel']); ?></td>
                            <td><?php echo esc_html($entry['status']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            <?php
            $sent = array();
            foreach (array(90, 30, 15, 7, 0) as $t) {
                if (!empty($notified[$t])) $sent[] = (pt_lang() === 'fr' ? 'J-' : 'D-') . $t;
            }
            ?>
            <p style="margin:14px 0 0;font-size:11px;color:#8fa3c8;">
                <?php echo esc_html(pt_t('Alertes déjà envoyées pour cette échéance :', 'Alerts already sent for this deadline:')); ?>
                <strong style="color:#c7cfe4;"><?php echo $sent ? esc_html(implode(', ', $sent)) : esc_html(pt_t('aucune', 'none')); ?></strong>
            </p>
        </div>
    </div>

    <script>
    (function () {
        var sel = document.getElementById('ptw-method');
        function tog() {
            var v = sel.value;
            document.getElementById('ptw-cloud-fields').style.display = (v === 'cloud') ? 'block' : 'none';
            document.getElementById('ptw-callmebot-fields').style.display = (v === 'callmebot') ? 'block' : 'none';
            document.getElementById('ptw-telegram-fields').style.display = (v === 'telegram') ? 'block' : 'none';
        }
        sel.addEventListener('change', tog);
        tog();

        var root = document.getElementById('ptw-live');
        if (!root) return;
        var end = parseInt(root.getAttribute('data-end'), 10) * 1000;
        function p(n) { return n < 10 ? '0' + n : '' + n; }
        function up() {
            var diff = end - Date.now();
            if (diff < 0) diff = 0;
            var s = Math.floor(diff / 1000);
            var d = Math.floor(s / 86400); s -= d * 86400;
            var h = Math.floor(s / 3600); s -= h * 3600;
            var m = Math.floor(s / 60); s -= m * 60;
            document.getElementById('ptw-d').textContent = d;
            document.getElementById('ptw-h').textContent = p(h);
            document.getElementById('ptw-m').textContent = p(m);
            document.getElementById('ptw-s').textContent = p(s);
        }
        up();
        setInterval(up, 1000);
    })();
    </script>
    <?php
}

/* ============================================================
   10. ASSISTANT DE CONFIGURATION INITIALE
   ============================================================ */

function ptimer_render_setup_page() {
    if (!current_user_can('manage_options')) return;

    $flash = ptimer_flash_get();
    $start = get_option('ptimer_start_date', '');
    $end   = get_option('ptimer_end_date', '');
    $email = get_option('ptimer_email', get_option('admin_email'));
    $wa    = get_option('ptimer_whatsapp', '');

    ptimer_admin_styles();
    ?>
    <div class="wrap ptw" style="max-width:720px;margin:0 auto;">
        <h1 style="color:#e8c96a;font-family:'Orbitron',sans-serif;text-align:center;">🛰️ <?php echo esc_html(pt_t('BIENVENUE — ELEVEN TIMER', 'WELCOME — ELEVEN TIMER')); ?></h1>
        <p style="text-align:center;color:#8fa3c8;"><?php echo esc_html(pt_t('Configurez votre abonnement en 30 secondes pour activer la surveillance.', 'Set up your subscription in 30 seconds to activate monitoring.')); ?></p>

        <?php if ($flash) : ?>
            <div class="ptw-flash <?php echo esc_attr($flash['type']); ?>"><?php echo esc_html($flash['msg']); ?></div>
        <?php endif; ?>

        <form method="post">
            <?php wp_nonce_field('ptimer_setup', 'ptimer_nonce'); ?>
            <input type="hidden" name="ptimer_page" value="setup">
            <input type="hidden" name="ptimer_finish_setup" value="1">

            <div class="ptw-card">
                <h2><?php echo esc_html(pt_t("1 • Période d'abonnement", '1 • Subscription period')); ?></h2>
                <div class="ptw-grid">
                    <div class="ptw-field">
                        <label><?php echo esc_html(pt_t("Début de l'abonnement", 'Subscription start')); ?></label>
                        <input type="date" name="ptimer_start_date" value="<?php echo esc_attr($start ? $start : date('Y-m-d')); ?>">
                    </div>
                    <div class="ptw-field">
                        <label><?php echo esc_html(pt_t("Fin de l'abonnement (expiration)", 'Subscription end (expiration)')); ?></label>
                        <input type="date" name="ptimer_end_date" value="<?php echo esc_attr($end); ?>" required>
                    </div>
                </div>
            </div>

            <div class="ptw-card">
                <h2><?php echo esc_html(pt_t('2 • Contacts de notification', '2 • Notification contacts')); ?></h2>
                <p class="desc"><?php echo esc_html(pt_t('Vous recevrez les rappels J-90, J-30, J-15 et J-7 sur ces canaux.', 'You will receive D-90, D-30, D-15 and D-7 reminders on these channels.')); ?></p>
                <div class="ptw-grid">
                    <div class="ptw-field">
                        <label>E-mail</label>
                        <input type="email" name="ptimer_email" value="<?php echo esc_attr($email); ?>">
                    </div>
                    <div class="ptw-field">
                        <label><?php echo esc_html(pt_t('WhatsApp (format international)', 'WhatsApp (international format)')); ?></label>
                        <input type="text" name="ptimer_whatsapp" value="<?php echo esc_attr($wa); ?>" placeholder="+12125550000">
                    </div>
                </div>
                <div class="ptw-hint">
                    ℹ️ <?php echo esc_html(pt_t('La passerelle de notification (Telegram, CallMeBot ou Cloud API) se configure ensuite dans la page principale du plugin.', 'The notification gateway (Telegram, CallMeBot or Cloud API) is configured afterwards in the main plugin page.')); ?>
                </div>
            </div>

            <div class="ptw-actions" style="justify-content:center;">
                <button type="submit" name="ptimer_action" value="save" class="btn-pt primary">🚀 <?php echo esc_html(pt_t('ACTIVER LA SURVEILLANCE', 'ACTIVATE MONITORING')); ?></button>
            </div>
        </form>
    </div>
    <?php
}

/* ============================================================
   11. WIDGET PUBLIC : ICÔNE T + MOT DE PASSE + ASTROLABE SAHARIEN
   ============================================================ */

add_action('wp_footer', 'ptimer_frontend_widget');

function ptimer_frontend_widget() {
    if (!get_option('ptimer_show_frontend', 1)) return;
    if (get_option('ptimer_admins_only') && !current_user_can('manage_options')) return;
    if (!get_option('ptimer_end_date')) return;

    $ajax  = esc_url(admin_url('admin-ajax.php'));
    $nonce = esc_js(wp_create_nonce('ptimer_nonce'));
    $site  = esc_html(get_bloginfo('name'));
    ?>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&display=swap" rel="stylesheet">
    <style>
    /* ---------- ICÔNE DISCRÈTE ---------- */
    #ptimer-badge{position:fixed;bottom:12px;right:12px;width:24px;height:24px;border-radius:50%;background:rgba(10,13,26,.55);border:1px solid rgba(232,201,106,.4);color:#e8c96a;font-family:'Orbitron',monospace;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;z-index:999998;cursor:pointer;opacity:.3;transition:.3s;backdrop-filter:blur(3px);user-select:none;}
    #ptimer-badge:hover{opacity:1;transform:scale(1.2);box-shadow:0 0 14px rgba(232,201,106,.65);}
    @media(max-width:600px){#ptimer-badge{width:20px;height:20px;font-size:9px;bottom:10px;right:10px;}}

    /* ---------- MODALES ---------- */
    .ptimer-modal{position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;display:flex;align-items:center;justify-content:center;opacity:0;visibility:hidden;transition:.35s ease;}
    .ptimer-modal.is-open{opacity:1;visibility:visible;}

    #ptimer-pwd-modal{background:rgba(3,5,14,.92);backdrop-filter:blur(6px);}
    #ptimer-timer-modal{background:linear-gradient(180deg,#04060d 0%,#0a1024 40%,#1c1308 78%,#3a250e 100%);}

    /* ---------- DÉCOR SAHARIEN ---------- */
    .pt-deco{position:absolute;pointer-events:none;}
    .pt-stars{top:0;left:0;right:0;bottom:0;overflow:hidden;}
    .pt-stars span{position:absolute;background:#fff;border-radius:50%;opacity:.1;animation:pttwinkle linear infinite;}
    @keyframes pttwinkle{0%,100%{opacity:.04;}50%{opacity:.95;}}

    .pt-moon{top:9%;right:13%;width:44px;height:44px;border-radius:50%;box-shadow:11px 7px 0 0 #f2e6c4;opacity:.85;filter:drop-shadow(0 0 14px rgba(242,230,196,.45));}
    @media(max-width:600px){.pt-moon{width:30px;height:30px;box-shadow:8px 5px 0 0 #f2e6c4;top:7%;right:9%;}}

    .pt-shooting{top:14%;left:18%;width:130px;height:1px;background:linear-gradient(90deg,#fff,transparent);opacity:0;animation:ptshoot 11s linear infinite;}
    .pt-shooting.s2{top:26%;left:55%;animation-delay:5.5s;animation-duration:13s;}
    @keyframes ptshoot{0%{transform:rotate(18deg) translateX(0);opacity:0;}3%{opacity:.9;}9%{transform:rotate(18deg) translateX(46vw);opacity:0;}100%{opacity:0;}}

    .pt-dunes{bottom:0;left:0;width:100%;height:auto;}
    .pt-dunes.back{opacity:.75;}

    .pt-sand{top:0;left:0;right:0;bottom:0;overflow:hidden;}
    .pt-sand span{position:absolute;bottom:-8px;border-radius:50%;background:rgba(232,201,106,.55);animation:ptsand linear infinite;}
    @keyframes ptsand{0%{transform:translate(0,0);opacity:0;}12%{opacity:.85;}85%{opacity:.2;}100%{transform:translate(var(--dx),-52vh);opacity:0;}}

    /* ---------- MOT DE PASSE ---------- */
    .ptimer-pwd-box{position:relative;width:min(340px,92vw);background:linear-gradient(160deg,#10142a,#181f3d);border:1px solid rgba(202,162,63,.5);border-radius:16px;padding:30px 26px;text-align:center;font-family:'Orbitron','Segoe UI',monospace;color:#eaf0ff;box-shadow:0 0 50px rgba(202,162,63,.15);transform:scale(.94);transition:.3s;}
    .ptimer-modal.is-open .ptimer-pwd-box{transform:none;}
    .ptimer-pwd-icon{font-size:30px;}
    .ptimer-pwd-box h3{margin:10px 0 6px;font-size:15px;letter-spacing:3px;color:#e8c96a;}
    .ptimer-pwd-box p{font-size:11px;color:#9aa6c4;line-height:1.6;margin:0 0 16px;font-family:'Segoe UI',Arial,sans-serif;}
    #ptimer-pwd-input{width:100%;box-sizing:border-box;background:#0b0e1f;border:1px solid #2c3560;border-radius:8px;padding:12px;color:#fff;font-size:15px;text-align:center;letter-spacing:3px;outline:none;transition:.25s;}
    #ptimer-pwd-input:focus{border-color:#e8c96a;box-shadow:0 0 12px rgba(232,201,106,.35);}
    #ptimer-pwd-btn{width:100%;margin-top:14px;background:linear-gradient(135deg,#caa23f,#a47b3b);border:none;border-radius:8px;padding:12px;color:#141414;font-weight:700;font-size:12px;letter-spacing:2px;cursor:pointer;transition:.25s;font-family:inherit;}
    #ptimer-pwd-btn:hover{filter:brightness(1.15);box-shadow:0 0 16px rgba(232,201,106,.5);}
    #ptimer-pwd-btn:disabled{opacity:.5;cursor:not-allowed;}
    #ptimer-pwd-msg{min-height:16px;margin-top:10px;font-size:10px;color:#ff7676;letter-spacing:1px;}
    .ptimer-shake{animation:ptshake .4s;}
    @keyframes ptshake{0%,100%{transform:translateX(0);}20%{transform:translateX(-8px);}40%{transform:translateX(8px);}60%{transform:translateX(-5px);}80%{transform:translateX(5px);}}

    .ptimer-x{position:absolute;top:8px;right:12px;background:none;border:none;color:#8fa3c8;font-size:22px;cursor:pointer;line-height:1;z-index:5;}
    .ptimer-x:hover{color:#fff;}

    /* ---------- CARTE ASTROLABE ---------- */
    .ptimer-card{--glow:87,227,137;position:relative;width:min(640px,94vw);max-height:96vh;overflow:auto;background:linear-gradient(168deg,rgba(28,21,11,.94),rgba(38,29,16,.9) 55%,rgba(20,14,8,.95));border:1px solid rgba(212,168,83,.55);outline:1px solid rgba(212,168,83,.16);outline-offset:-7px;border-radius:20px;padding:30px 30px 20px;text-align:center;font-family:'Orbitron','Segoe UI',monospace;color:#f0e6cf;backdrop-filter:blur(10px);box-shadow:0 0 90px rgba(212,168,83,.14),inset 0 0 60px rgba(0,0,0,.5);transform:translateY(24px) scale(.96);transition:.4s cubic-bezier(.2,.9,.25,1.2);scrollbar-width:thin;}
    .ptimer-modal.is-open .ptimer-card{transform:none;}
    .ptimer-card.lvl-warn{--glow:255,215,106;}
    .ptimer-card.lvl-alert{--glow:255,161,74;}
    .ptimer-card.lvl-crit{--glow:255,93,93;}
    .ptimer-card.expired{--glow:255,77,77;}

    .orn{position:absolute;color:#d4a853;font-size:13px;text-shadow:0 0 10px rgba(212,168,83,.9);z-index:2;}
    .orn-tl{top:9px;left:13px;}.orn-tr{top:9px;right:13px;}
    .orn-bl{bottom:9px;left:13px;}.orn-br{bottom:9px;right:13px;}

    .ptimer-sub{font-size:9px;letter-spacing:4px;color:#b9975c;}
    .ptimer-title{margin:7px 0 0;font-size:clamp(15px,3vw,20px);letter-spacing:3px;color:#fdf6e3;text-shadow:0 0 22px rgba(212,168,83,.45);}
    .pt-divider{display:flex;align-items:center;gap:10px;margin:12px auto 2px;max-width:300px;color:#d4a853;}
    .pt-divider::before,.pt-divider::after{content:'';flex:1;height:1px;}
    .pt-divider::before{background:linear-gradient(90deg,transparent,rgba(212,168,83,.65));}
    .pt-divider::after{background:linear-gradient(270deg,transparent,rgba(212,168,83,.65));}
    .pt-divider span{font-size:9px;text-shadow:0 0 8px rgba(212,168,83,.8);}

    .pt-statusline{display:flex;justify-content:center;align-items:center;gap:12px;margin-top:12px;flex-wrap:wrap;}
    .ptimer-pill{display:inline-block;padding:5px 14px;border-radius:999px;font-size:10px;letter-spacing:2px;border:1px solid currentColor;font-weight:700;}
    #ptimer-site{font-size:10px;color:#b9975c;letter-spacing:1px;}

    /* ---------- ASTROLABE ---------- */
    .pt-astro{position:relative;width:min(238px,62vw);margin:14px auto 2px;}
    .pt-astro-svg{display:block;width:100%;height:auto;}
    .pt-ring-a,.pt-ring-b{transform-box:fill-box;transform-origin:center;}
    .pt-ring-a{animation:ptspin 46s linear infinite;}
    .pt-ring-b{animation:ptspin 30s linear infinite reverse;}
    @keyframes ptspin{to{transform:rotate(360deg);}}
    #ptArc{transition:stroke-dashoffset 1s linear,stroke .6s ease;}
    .ptimer-card.expired #ptArc{stroke:#ff4d4d;}
    .ptimer-card.expired .pt-ring-a,.ptimer-card.expired .pt-ring-b{animation-play-state:paused;}

    .pt-core{position:absolute;top:0;left:0;right:0;bottom:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;}
    .pt-core-glow{position:absolute;width:70%;aspect-ratio:1;border-radius:50%;background:radial-gradient(circle,rgba(var(--glow),.32),transparent 66%);animation:ptpulse 2.6s ease-in-out infinite;z-index:-1;}
    @keyframes ptpulse{0%,100%{transform:scale(.92);opacity:.75;}50%{transform:scale(1.08);opacity:1;}}
    .pt-days span{font-size:clamp(40px,9vw,54px);font-weight:900;line-height:1;color:#f7ecd4;text-shadow:0 0 22px rgba(var(--glow),.75);}
    .pt-days-lbl{font-size:8px;letter-spacing:3px;color:#b9975c;}
    .ptimer-card.expired .pt-days span{color:#ff5d5d;animation:ptblink 1s steps(2) infinite;}
    @keyframes ptblink{50%{opacity:.35;}}

    /* ---------- HORLOGE H:M:S ---------- */
    .ptimer-grid{display:flex;justify-content:center;align-items:flex-end;gap:8px;margin:14px 0 4px;}
    .ptimer-grid .unit{min-width:64px;}
    .ptimer-grid .val{font-size:clamp(24px,5vw,38px);font-weight:700;line-height:1;color:#f7ecd4;text-shadow:0 0 16px rgba(var(--glow),.55);}
    .ptimer-grid .lbl{font-size:8px;letter-spacing:3px;color:#b9975c;margin-top:7px;}
    .ptimer-grid .sep{font-size:12px;color:#d4a853;padding-bottom:20px;animation:ptsep 1s ease-in-out infinite;}
    @keyframes ptsep{0%,100%{opacity:.45;transform:scale(.85);}50%{opacity:1;transform:scale(1.15);}}

    /* ---------- ROUTE CARAVANE ---------- */
    .pt-route{display:flex;align-items:center;gap:10px;margin:16px 4px 6px;}
    .pt-node{color:#d4a853;font-size:12px;text-shadow:0 0 8px rgba(212,168,83,.8);}
    .pt-route-track{flex:1;height:6px;border-radius:99px;background:repeating-linear-gradient(90deg,#2b2340 0 9px,#1b1628 9px 18px);border:1px solid #372c4e;overflow:hidden;}
    .pt-route-track .bar{height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,#2ec4b6,#e8c96a);box-shadow:0 0 12px rgba(232,201,106,.6);transition:width .8s ease;}
    .ptimer-meta{display:flex;justify-content:space-between;gap:10px;font-size:9px;letter-spacing:1px;color:#a08c62;flex-wrap:wrap;}
    .ptimer-foot{margin-top:16px;padding-top:10px;border-top:1px solid rgba(212,168,83,.18);font-size:8px;letter-spacing:3px;color:#8a744c;line-height:2;}

    @media(max-width:520px){
        .ptimer-card{padding:24px 14px 14px;}
        .ptimer-grid .unit{min-width:52px;}
        .ptimer-grid .sep{padding-bottom:14px;}
    }
    </style>

    <div id="ptimer-badge" title="Eleven Timer">T</div>

    <div id="ptimer-pwd-modal" class="ptimer-modal">
        <div class="ptimer-pwd-box" id="ptimer-pwd-box">
            <button class="ptimer-x" data-ptimer-close>&times;</button>
            <div class="ptimer-pwd-icon">🔒</div>
            <h3><?php echo esc_html(pt_t('ACCÈS SÉCURISÉ', 'SECURE ACCESS')); ?></h3>
            <p><?php echo esc_html(pt_t('Zone réservée au propriétaire du site.', 'Area reserved for the site owner.')); ?><br><?php echo esc_html(pt_t('Entrez le mot de passe pour consulter la garde du temps.', 'Enter the password to view the timekeeping.')); ?></p>
            <input type="password" id="ptimer-pwd-input" placeholder="••••••••••" autocomplete="off">
            <div id="ptimer-pwd-msg"></div>
            <button id="ptimer-pwd-btn"><?php echo esc_html(pt_t('AUTHENTIFIER', 'AUTHENTICATE')); ?></button>
        </div>
    </div>

    <div id="ptimer-timer-modal" class="ptimer-modal">
        <div class="pt-deco pt-stars" id="ptimer-stars"></div>
        <div class="pt-deco pt-moon"></div>
        <span class="pt-deco pt-shooting"></span>
        <span class="pt-deco pt-shooting s2"></span>
        <svg class="pt-deco pt-dunes back" viewBox="0 0 1440 220" preserveAspectRatio="none" aria-hidden="true"><path fill="#191207" d="M0,128 L90,112 C210,90 330,118 450,126 C570,134 690,104 810,98 C930,92 1050,116 1170,122 C1290,128 1380,110 1440,104 L1440,220 L0,220 Z"/></svg>
        <svg class="pt-deco pt-dunes front" viewBox="0 0 1440 170" preserveAspectRatio="none" aria-hidden="true"><path fill="#0e0a05" d="M0,96 L120,84 C260,66 400,92 540,98 C680,104 820,72 960,68 C1100,64 1240,88 1360,86 L1440,80 L1440,170 L0,170 Z"/></svg>
        <div class="pt-deco pt-sand" id="ptimer-sand"></div>

        <div class="ptimer-card lvl-ok" id="ptimer-card">
            <span class="orn orn-tl">✦</span><span class="orn orn-tr">✦</span>
            <span class="orn orn-bl">✦</span><span class="orn orn-br">✦</span>
            <button class="ptimer-x" data-ptimer-close>&times;</button>

            <div class="ptimer-sub">ELEVEN TIMER • <?php echo esc_html(pt_t('LA GARDE DU TEMPS', 'THE TIMEKEEPING')); ?></div>
            <h2 class="ptimer-title"><?php echo esc_html(pt_t("SURVEILLANCE D'HÉBERGEMENT", 'HOSTING MONITORING')); ?></h2>
            <div class="pt-divider"><span>❖</span></div>

            <div class="pt-statusline">
                <span id="ptimer-pill" class="ptimer-pill" style="color:#57e389;">—</span>
                <span id="ptimer-site"><?php echo $site; ?></span>
            </div>

            <div class="pt-astro">
                <svg viewBox="0 0 200 200" class="pt-astro-svg" aria-hidden="true">
                    <defs>
                        <linearGradient id="ptGold" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#f7e7c3"/>
                            <stop offset="55%" stop-color="#d4a853"/>
                            <stop offset="100%" stop-color="#b07a2a"/>
                        </linearGradient>
                    </defs>
                    <circle cx="100" cy="100" r="96" fill="none" stroke="rgba(212,168,83,.22)" stroke-width="1"/>
                    <circle cx="100" cy="100" r="90" fill="none" stroke="rgba(212,168,83,.4)" stroke-width="4" stroke-dasharray="1.2 10.6"/>
                    <g class="pt-ring-a"><circle cx="100" cy="100" r="78" fill="none" stroke="rgba(212,168,83,.35)" stroke-width="1.4" stroke-dasharray="10 6"/></g>
                    <g class="pt-ring-b"><circle cx="100" cy="100" r="56" fill="none" stroke="rgba(46,196,182,.4)" stroke-width="1" stroke-dasharray="2 5"/></g>
                    <circle cx="100" cy="100" r="67" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="4"/>
                    <circle id="ptArc" cx="100" cy="100" r="67" fill="none" stroke="url(#ptGold)" stroke-width="4" stroke-linecap="round" transform="rotate(-90 100 100)" stroke-dasharray="421" stroke-dashoffset="421"/>
                    <g id="ptMarker"><path d="M100 25 l4.5 6.5 -4.5 6.5 -4.5 -6.5 Z" fill="#f7e7c3"/></g>
                </svg>
                <div class="pt-core">
                    <div class="pt-core-glow"></div>
                    <div class="pt-days"><span id="ptimer-d">--</span></div>
                    <div class="pt-days-lbl" id="ptimer-days-lbl"><?php echo esc_html(pt_t('JOURS RESTANTS', 'DAYS REMAINING')); ?></div>
                </div>
            </div>

            <div class="ptimer-grid">
                <div class="unit"><div class="val" id="ptimer-h">--</div><div class="lbl"><?php echo esc_html(pt_t('HEURES', 'HOURS')); ?></div></div>
                <div class="sep">◆</div>
                <div class="unit"><div class="val" id="ptimer-m">--</div><div class="lbl"><?php echo esc_html(pt_t('MINUTES', 'MINUTES')); ?></div></div>
                <div class="sep">◆</div>
                <div class="unit"><div class="val" id="ptimer-s">--</div><div class="lbl"><?php echo esc_html(pt_t('SECONDES', 'SECONDS')); ?></div></div>
            </div>

            <div class="pt-route">
                <span class="pt-node">✦</span>
                <div class="pt-route-track"><div class="bar" id="ptimer-bar"></div></div>
                <span class="pt-node">⚑</span>
            </div>
            <div class="ptimer-meta">
                <span id="ptimer-bar-label">—</span>
                <span>☀ <?php echo esc_html(pt_t('Début : ', 'Start: ') . ptimer_fmt_date(ptimer_start_ts())); ?> &nbsp;•&nbsp; <?php echo esc_html(pt_t('Fin : ', 'End: ') . ptimer_fmt_date(ptimer_end_ts())); ?> ☾</span>
            </div>
            <div class="ptimer-foot">─── ❖ ───<br>ELEVEN TIMER • <?php echo esc_html(pt_t('ACCÈS VÉRIFIÉ ✓', 'ACCESS VERIFIED ✓')); ?></div>
        </div>
    </div>

    <script>
    (function () {
        var AJAX = '<?php echo $ajax; ?>';
        var NONCE = '<?php echo $nonce; ?>';

        var badge = document.getElementById('ptimer-badge');
        var pwdModal = document.getElementById('ptimer-pwd-modal');
        var timerModal = document.getElementById('ptimer-timer-modal');
        var pwdBox = document.getElementById('ptimer-pwd-box');
        var input = document.getElementById('ptimer-pwd-input');
        var msg = document.getElementById('ptimer-pwd-msg');
        var btn = document.getElementById('ptimer-pwd-btn');
        var timerId = null;

        function open(m) { m.classList.add('is-open'); }
        function close(m) {
            m.classList.remove('is-open');
            if (m === timerModal && timerId) { clearInterval(timerId); timerId = null; }
        }

        badge.addEventListener('click', function () {
            msg.textContent = '';
            input.value = '';
            btn.disabled = false;
            open(pwdModal);
            setTimeout(function () { input.focus(); }, 200);
        });

        Array.prototype.forEach.call(document.querySelectorAll('[data-ptimer-close]'), function (b) {
            b.addEventListener('click', function () { close(b.closest('.ptimer-modal')); });
        });

        [pwdModal, timerModal].forEach(function (m) {
            m.addEventListener('click', function (e) { if (e.target === m) close(m); });
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') { close(pwdModal); close(timerModal); }
        });

        function pad(n) { return n < 10 ? '0' + n : '' + n; }

        var ARC_C = 421;

        var L10N = {
            expiredLbl: '<?php echo esc_js(pt_t('HÉBERGEMENT EXPIRÉ', 'HOSTING EXPIRED')); ?>',
            expiredPill: '<?php echo esc_js(pt_t('⚠ EXPIRÉ', '⚠ EXPIRED')); ?>',
            caravanDone: '<?php echo esc_js(pt_t('Caravane arrivée au terme — 100% consommé', 'Caravan reached the end — 100% consumed')); ?>',
            consumed: '<?php echo esc_js(pt_t('% consommé', '% consumed')); ?>',
            ok: '<?php echo esc_js(pt_t('✔ OPÉRATIONNEL', '✔ OPERATIONAL')); ?>',
            warn: '<?php echo esc_js(pt_t('◐ ATTENTION', '◐ ATTENTION')); ?>',
            alert: '<?php echo esc_js(pt_t('▲ ALERTE', '▲ ALERT')); ?>',
            crit: '<?php echo esc_js(pt_t('● CRITIQUE', '● CRITICAL')); ?>'
        };

        function tick(data) {
            var card = document.getElementById('ptimer-card');
            var pill = document.getElementById('ptimer-pill');
            var arc = document.getElementById('ptArc');
            var marker = document.getElementById('ptMarker');
            var now = Date.now();
            var end = data.end_ts * 1000;
            var diff = end - now;
            var elD = document.getElementById('ptimer-d');
            var elH = document.getElementById('ptimer-h');
            var elM = document.getElementById('ptimer-m');
            var elS = document.getElementById('ptimer-s');
            var lbl = document.getElementById('ptimer-days-lbl');

            var st = data.start_ts * 1000;
            var pct = (st && end > st) ? Math.min(100, Math.max(0, (now - st) / (end - st) * 100)) : 0;

            if (diff <= 0) {
                elD.textContent = '0';
                elH.textContent = '00'; elM.textContent = '00'; elS.textContent = '00';
                lbl.textContent = L10N.expiredLbl;
                card.classList.add('expired');
                card.classList.remove('lvl-ok', 'lvl-warn', 'lvl-alert', 'lvl-crit');
                pill.textContent = L10N.expiredPill;
                pill.style.color = '#ff4d4d';
                arc.style.strokeDashoffset = 0;
                marker.setAttribute('transform', 'rotate(360 100 100)');
                document.getElementById('ptimer-bar').style.width = '100%';
                document.getElementById('ptimer-bar-label').textContent = L10N.caravanDone;
                return;
            }
            card.classList.remove('expired');

            var s = Math.floor(diff / 1000);
            var d = Math.floor(s / 86400); s -= d * 86400;
            var h = Math.floor(s / 3600); s -= h * 3600;
            var m = Math.floor(s / 60); s -= m * 60;

            elD.textContent = d;
            elH.textContent = pad(h);
            elM.textContent = pad(m);
            elS.textContent = pad(s);

            card.classList.remove('lvl-ok', 'lvl-warn', 'lvl-alert', 'lvl-crit');
            var lvl = d <= 7 ? 'lvl-crit' : d <= 30 ? 'lvl-alert' : d <= 90 ? 'lvl-warn' : 'lvl-ok';
            card.classList.add(lvl);

            var map = {
                'lvl-ok': [L10N.ok, '#57e389'],
                'lvl-warn': [L10N.warn, '#ffd76a'],
                'lvl-alert': [L10N.alert, '#ffa14a'],
                'lvl-crit': [L10N.crit, '#ff5d5d']
            };
            pill.textContent = map[lvl][0];
            pill.style.color = map[lvl][1];

            arc.style.strokeDashoffset = ARC_C * (1 - pct / 100);
            marker.setAttribute('transform', 'rotate(' + (pct * 3.6) + ' 100 100)');
            document.getElementById('ptimer-bar').style.width = pct + '%';
            document.getElementById('ptimer-bar-label').textContent = pct.toFixed(1) + L10N.consumed;
        }

        function buildStars() {
            var c = document.getElementById('ptimer-stars');
            if (c.getAttribute('data-done')) return;
            c.setAttribute('data-done', '1');
            for (var i = 0; i < 110; i++) {
                var sp = document.createElement('span');
                sp.style.left = (Math.random() * 100) + '%';
                sp.style.top = (Math.random() * 72) + '%';
                var sz = Math.random() * 2 + 1;
                sp.style.width = sz + 'px';
                sp.style.height = sz + 'px';
                sp.style.animationDuration = (Math.random() * 3 + 2) + 's';
                sp.style.animationDelay = (Math.random() * 4) + 's';
                c.appendChild(sp);
            }
        }

        function buildSand() {
            var c = document.getElementById('ptimer-sand');
            if (c.getAttribute('data-done')) return;
            c.setAttribute('data-done', '1');
            for (var i = 0; i < 26; i++) {
                var sp = document.createElement('span');
                var sz = Math.random() * 2.4 + 1.4;
                sp.style.left = (Math.random() * 100) + '%';
                sp.style.width = sz + 'px';
                sp.style.height = sz + 'px';
                sp.style.setProperty('--dx', ((Math.random() * 160 - 80)) + 'px');
                sp.style.animationDuration = (Math.random() * 8 + 6) + 's';
                sp.style.animationDelay = (Math.random() * 8) + 's';
                c.appendChild(sp);
            }
        }

        function submitPwd() {
            var pwd = input.value;
            if (!pwd) { input.focus(); return; }
            btn.disabled = true;
            msg.textContent = '';

            fetch(AJAX, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ action: 'ptimer_verify', nonce: NONCE, password: pwd })
            })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                btn.disabled = false;
                if (res.success) {
                    close(pwdModal);
                    buildStars();
                    buildSand();
                    open(timerModal);
                    var data = res.data;
                    clearInterval(timerId);
                    tick(data);
                    timerId = setInterval(function () { tick(data); }, 1000);
                } else {
                    msg.textContent = res.data.message;
                    pwdBox.classList.remove('ptimer-shake');
                    void pwdBox.offsetWidth;
                    pwdBox.classList.add('ptimer-shake');
                    if (res.data.locked) btn.disabled = true;
                    input.value = '';
                    input.focus();
                }
            })
            .catch(function () {
                btn.disabled = false;
                msg.textContent = '<?php echo esc_js(pt_t('Erreur réseau, réessayez.', 'Network error, please try again.')); ?>';
            });
        }

        btn.addEventListener('click', submitPwd);
        input.addEventListener('keydown', function (e) { if (e.key === 'Enter') submitPwd(); });
    })();
    </script>
    <?php
}

/* ============================================================
   12. AJAX — VÉRIFICATION DU MOT DE PASSE (CÔTÉ SERVEUR)
   ============================================================ */

add_action('wp_ajax_ptimer_verify', 'ptimer_ajax_verify');
add_action('wp_ajax_nopriv_ptimer_verify', 'ptimer_ajax_verify');

function ptimer_ajax_verify() {
    check_ajax_referer('ptimer_nonce', 'nonce');

    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', $_SERVER['REMOTE_ADDR']) : 'unknown';
    $attempt_key = 'ptimer_att_' . md5($ip);
    $attempts = (int) get_transient($attempt_key);

    if ($attempts >= 5) {
        wp_send_json_error(array(
            'message' => pt_t('Trop de tentatives. Accès bloqué 15 minutes.', 'Too many attempts. Access blocked for 15 minutes.'),
            'locked'  => true,
        ));
    }

    $pwd  = isset($_POST['password']) ? wp_unslash($_POST['password']) : '';
    $hash = get_option('ptimer_password');

    if (!$hash || !wp_check_password($pwd, $hash)) {
        set_transient($attempt_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
        $left = 4 - $attempts;
        wp_send_json_error(array(
            'message' => pt_t('Mot de passe incorrect.', 'Incorrect password.') . ($left > 0 ? ' ' . pt_t('Tentatives restantes : ', 'Attempts remaining: ') . $left : ''),
        ));
    }

    delete_transient($attempt_key);

    wp_send_json_success(array(
        'end_ts'   => ptimer_end_ts(),
        'start_ts' => ptimer_start_ts(),
        'site'     => get_bloginfo('name'),
    ));
}
