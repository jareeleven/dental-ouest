<?php
/*
Plugin Name: Eleven Timer
Plugin URI: https://www.provencetour-dz.com/
Description: Surveillance d'abonnement d'hébergement : icône discrète "T" en bas à droite, accès protégé par mot de passe, compte à rebours futuriste style Star Wars, alertes doublées E-mail + WhatsApp à J-90, J-30, J-15 et J-7 avant expiration.
Version: 4.1
Author: Gafsi Abdeldjalil
Author URI: https://www.provencetour-dz.com/
Text Domain: eleven-timer
*/

if (!defined('ABSPATH')) exit;

define('PTIMER_VERSION', '4.1');
define('PTIMER_DEFAULT_PASSWORD', 'Eleven1975@');

/* ============================================================
   1. ACTIVATION / DÉSACTIVATION / DÉSINSTALLATION
   ============================================================ */

function ptimer_activate() {
    if (!get_option('ptimer_password')) {
        add_option('ptimer_password', wp_hash_password(PTIMER_DEFAULT_PASSWORD));
    }
    add_option('ptimer_notified', array());
    add_option('ptimer_setup_done', 0);
    add_option('ptimer_show_frontend', 1);
    add_option('ptimer_admins_only', 0);
    add_option('ptimer_wa_method', 'callmebot');
    add_option('ptimer_setup_redirect', 1);
    if (!wp_next_scheduled('ptimer_daily_check')) {
        wp_schedule_event(strtotime('tomorrow 09:00:00'), 'daily', 'ptimer_daily_check');
    }
}
register_activation_hook(__FILE__, 'ptimer_activate');

function ptimer_deactivate() {
    wp_clear_scheduled_hook('ptimer_daily_check');
}
register_deactivation_hook(__FILE__, 'ptimer_deactivate');

function ptimer_uninstall() {
    $keys = array(
        'ptimer_password', 'ptimer_start_date', 'ptimer_end_date',
        'ptimer_email', 'ptimer_whatsapp', 'ptimer_wa_method',
        'ptimer_wa_token', 'ptimer_wa_phone_id', 'ptimer_wa_apikey',
        'ptimer_notified', 'ptimer_setup_done', 'ptimer_show_frontend',
        'ptimer_admins_only', 'ptimer_log', 'ptimer_migrated', 'ptimer_setup_redirect',
    );
    foreach ($keys as $k) {
        delete_option($k);
    }
    delete_transient('ptimer_flash');
    wp_clear_scheduled_hook('ptimer_daily_check');
}
register_uninstall_hook(__FILE__, 'ptimer_uninstall');

/* ============================================================
   2. MIGRATION DEPUIS L'ANCIENNE VERSION DU PLUGIN
   ============================================================ */

function ptimer_migrate_old_options() {
    if (get_option('ptimer_migrated')) return;
    $old = get_option('provencetour_expiration_date');
    if ($old && !get_option('ptimer_end_date')) {
        update_option('ptimer_end_date', $old);
        if (!get_option('ptimer_start_date')) {
            update_option('ptimer_start_date', date('Y-m-d', strtotime($old . ' -1 year')));
        }
    }
    update_option('ptimer_migrated', 1);
}

/* ============================================================
   3. FONCTIONS UTILITAIRES
   ============================================================ */

function ptimer_end_ts() {
    $d = get_option('ptimer_end_date');
    return $d ? strtotime($d . ' 23:59:59') : 0;
}

function ptimer_start_ts() {
    $d = get_option('ptimer_start_date');
    return $d ? strtotime($d . ' 00:00:00') : 0;
}

function ptimer_days_left() {
    $end = ptimer_end_ts();
    if (!$end) return null;
    return (int) floor(($end - time()) / DAY_IN_SECONDS);
}

function ptimer_status($days) {
    if ($days === null) return array('label' => 'NON CONFIGURÉ', 'color' => '#8a8f9f');
    if ($days <= 0)  return array('label' => 'EXPIRÉ',     'color' => '#ff4d4d');
    if ($days <= 7)  return array('label' => 'CRITIQUE',   'color' => '#ff5d5d');
    if ($days <= 30) return array('label' => 'ALERTE',     'color' => '#ffa14a');
    if ($days <= 90) return array('label' => 'ATTENTION',  'color' => '#ffd76a');
    return array('label' => 'OPÉRATIONNEL', 'color' => '#57e389');
}

function ptimer_fmt_date($ts) {
    return $ts ? date_i18n('d/m/Y', $ts) : '—';
}

function ptimer_log($channel, $status) {
    $log = get_option('ptimer_log', array());
    array_unshift($log, array(
        'time'    => current_time('mysql'),
        'channel' => $channel,
        'status'  => $status,
    ));
    update_option('ptimer_log', array_slice($log, 0, 30));
}

function ptimer_flash_set($msg, $type = 'ok') {
    set_transient('ptimer_flash', array('msg' => $msg, 'type' => $type), 120);
}

function ptimer_flash_get() {
    $f = get_transient('ptimer_flash');
    if ($f) delete_transient('ptimer_flash');
    return $f;
}

/* ============================================================
   4. MENU ADMIN + REDIRECTION CONFIGURATION INITIALE
   ============================================================ */

add_action('admin_menu', function () {
    add_menu_page(
        'Eleven Timer',
        '⏳ Eleven Timer',
        'manage_options',
        'eleven_timer',
        'ptimer_render_settings_page',
        'dashicons-clock',
        3
    );
    add_submenu_page(
        'eleven_timer',
        'Configuration initiale',
        'Configuration initiale',
        'manage_options',
        'eleven_timer_setup',
        'ptimer_render_setup_page'
    );
});

add_action('admin_init', function () {
    ptimer_migrate_old_options();

    if (!wp_next_scheduled('ptimer_daily_check')) {
        wp_schedule_event(time() + 300, 'daily', 'ptimer_daily_check');
    }

    if (get_option('ptimer_setup_redirect') && current_user_can('manage_options')) {
        delete_option('ptimer_setup_redirect');
        wp_safe_redirect(admin_url('admin.php?page=eleven_timer_setup'));
        exit;
    }

    ptimer_handle_post_actions();
});

add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;
    if (get_option('ptimer_setup_done')) return;
    $page = isset($_GET['page']) ? $_GET['page'] : '';
    if ($page === 'eleven_timer_setup' || $page === 'eleven_timer') return;
    echo '<div class="notice notice-warning"><p><strong>⏳ Eleven Timer :</strong> le plugin doit être configuré (dates d\'abonnement + contacts de notification). ';
    echo '<a href="' . esc_url(admin_url('admin.php?page=eleven_timer_setup')) . '" class="button button-primary" style="margin-left:8px;">Configurer maintenant</a></p></div>';
});

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    array_unshift($links, '<a href="' . admin_url('admin.php?page=eleven_timer') . '">Réglages</a>');
    return $links;
});

/* ============================================================
   5. TRAITEMENT DES FORMULAIRES ADMIN
   ============================================================ */

function ptimer_verify_nonce_field($action) {
    if (!isset($_POST['ptimer_nonce']) || !wp_verify_nonce($_POST['ptimer_nonce'], $action)) {
        wp_die('Vérification de sécurité échouée.');
    }
}

function ptimer_save_settings() {
    $start   = isset($_POST['ptimer_start_date']) ? sanitize_text_field(wp_unslash($_POST['ptimer_start_date'])) : '';
    $end     = isset($_POST['ptimer_end_date']) ? sanitize_text_field(wp_unslash($_POST['ptimer_end_date'])) : '';
    $email   = isset($_POST['ptimer_email']) ? sanitize_email(wp_unslash($_POST['ptimer_email'])) : '';
    $wa      = isset($_POST['ptimer_whatsapp']) ? preg_replace('/[^0-9+]/', '', wp_unslash($_POST['ptimer_whatsapp'])) : '';
    $method  = (isset($_POST['ptimer_wa_method']) && $_POST['ptimer_wa_method'] === 'cloud') ? 'cloud' : 'callmebot';
    $token   = isset($_POST['ptimer_wa_token']) ? sanitize_text_field(wp_unslash($_POST['ptimer_wa_token'])) : '';
    $pid     = isset($_POST['ptimer_wa_phone_id']) ? sanitize_text_field(wp_unslash($_POST['ptimer_wa_phone_id'])) : '';
    $apikey  = isset($_POST['ptimer_wa_apikey']) ? sanitize_text_field(wp_unslash($_POST['ptimer_wa_apikey'])) : '';
    $showf   = !empty($_POST['ptimer_show_frontend']) ? 1 : 0;
    $admonly = !empty($_POST['ptimer_admins_only']) ? 1 : 0;

    $old_end = get_option('ptimer_end_date');

    update_option('ptimer_start_date', $start ? date('Y-m-d', strtotime($start)) : '');
    update_option('ptimer_end_date', $end ? date('Y-m-d', strtotime($end)) : '');
    update_option('ptimer_email', $email);
    update_option('ptimer_whatsapp', $wa);
    update_option('ptimer_wa_method', $method);
    update_option('ptimer_wa_token', $token);
    update_option('ptimer_wa_phone_id', $pid);
    update_option('ptimer_wa_apikey', $apikey);
    update_option('ptimer_show_frontend', $showf);
    update_option('ptimer_admins_only', $admonly);

    $p1 = isset($_POST['ptimer_pass1']) ? wp_unslash($_POST['ptimer_pass1']) : '';
    $p2 = isset($_POST['ptimer_pass2']) ? wp_unslash($_POST['ptimer_pass2']) : '';

    if ($p1 !== '' || $p2 !== '') {
        if ($p1 === $p2 && strlen($p1) >= 6) {
            update_option('ptimer_password', wp_hash_password($p1));
            ptimer_flash_set("Mot de passe d'accès mis à jour avec succès.");
        } else {
            ptimer_flash_set('Les mots de passe ne correspondent pas (minimum 6 caractères).', 'err');
        }
    }

    if ($end && date('Y-m-d', strtotime($end)) !== $old_end) {
        update_option('ptimer_notified', array());
        ptimer_log('Système', "Nouvelle date d'expiration enregistrée — alertes réinitialisées.");
    }
}

function ptimer_handle_post_actions() {
    if (!is_admin() || !current_user_can('manage_options')) return;
    if (!isset($_POST['ptimer_action'])) return;

    $page = isset($_POST['ptimer_page']) ? sanitize_key($_POST['ptimer_page']) : 'main';
    ptimer_verify_nonce_field('ptimer_' . $page);

    $act = sanitize_key(wp_unslash($_POST['ptimer_action']));
    ptimer_save_settings();

    $redirect = admin_url('admin.php?page=' . ($page === 'setup' ? 'eleven_timer_setup' : 'eleven_timer'));

    if ($act === 'save') {
        if (!empty($_POST['ptimer_finish_setup'])) {
            update_option('ptimer_setup_done', 1);
            ptimer_log('Système', 'Configuration initiale terminée — surveillance activée.');
            wp_safe_redirect(admin_url('admin.php?page=eleven_timer'));
            exit;
        }
        if (!ptimer_flash_get()) ptimer_flash_set('Réglages enregistrés avec succès.');

    } elseif ($act === 'test_email') {
        $body = '<p>Ceci est un <strong>e-mail de test</strong> du système de surveillance d\'hébergement Eleven Timer.</p>'
              . '<p>Date d\'expiration actuelle : <strong>' . esc_html(ptimer_fmt_date(ptimer_end_ts())) . '</strong></p>';
        $res = ptimer_send_email('🔔 TEST — Eleven Timer', $body);
        ptimer_flash_set($res === true ? 'E-mail de test envoyé avec succès.' : 'Échec de l\'envoi e-mail : ' . $res, $res === true ? 'ok' : 'err');

    } elseif ($act === 'test_whatsapp') {
        $msg = "🔔 TEST Eleven Timer\n\nMessage de test du systeme de surveillance d'hebergement.\nDate d'expiration : " . ptimer_fmt_date(ptimer_end_ts());
        $res = ptimer_send_whatsapp($msg);
        ptimer_flash_set($res === true ? 'WhatsApp de test envoyé avec succès.' : 'Échec envoi WhatsApp : ' . $res, $res === true ? 'ok' : 'err');

    } elseif ($act === 'run_check') {
        ptimer_run_daily_check();
        ptimer_flash_set('Vérification effectuée — consultez le journal des envois ci-dessous.');

    } elseif ($act === 'reset_flags') {
        update_option('ptimer_notified', array());
        ptimer_log('Système', 'Historique des alertes réinitialisé manuellement.');
        ptimer_flash_set('Historique des alertes réinitialisé — les rappels seront renvoyés aux prochaines échéances.');
    }

    wp_safe_redirect($redirect);
    exit;
}

/* ============================================================
   6. ENVOI DES NOTIFICATIONS (E-MAIL + WHATSAPP)
   ============================================================ */

function ptimer_email_template($title, $body) {
    $site = get_bloginfo('name');
    $url  = home_url();
    return '<!DOCTYPE html><html><body style="margin:0;padding:24px;background:#0b0e1f;font-family:Arial,Helvetica,sans-serif;">'
        . '<div style="max-width:560px;margin:0 auto;background:#12162b;border:1px solid #caa23f;border-radius:14px;overflow:hidden;">'
        . '<div style="background:linear-gradient(135deg,#1a1f3d,#2c2f48);padding:20px 26px;border-bottom:1px solid #caa23f;">'
        . '<div style="color:#e8c96a;font-size:11px;letter-spacing:2px;">ELEVEN TIMER • SYSTÈME DE SURVEILLANCE</div>'
        . '<h1 style="color:#ffffff;font-size:19px;margin:8px 0 0;">' . esc_html($title) . '</h1></div>'
        . '<div style="padding:24px 26px;color:#d7dbe8;font-size:14px;line-height:1.7;">' . $body . '</div>'
        . '<div style="padding:16px 26px;background:#0b0e1f;color:#8a8f9f;font-size:11px;border-top:1px solid #262b45;">'
        . 'Site surveillé : ' . esc_html($url) . ' — ' . esc_html($site) . '<br>Message automatique, merci de ne pas répondre.</div>'
        . '</div></body></html>';
}

function ptimer_send_email($subject, $html_body) {
    $to = get_option('ptimer_email');
    if (!$to || !is_email($to)) {
        ptimer_log('E-mail', 'ÉCHEC — adresse e-mail invalide ou manquante.');
        return 'adresse e-mail invalide ou manquante.';
    }
    $headers = array('Content-Type: text/html; charset=UTF-8');
    $ok = wp_mail($to, $subject, ptimer_email_template($subject, $html_body), $headers);
    if ($ok) {
        ptimer_log('E-mail', 'Envoyé à ' . $to . ' — ' . $subject);
        return true;
    }
    ptimer_log('E-mail', 'ÉCHEC envoi à ' . $to . ' — ' . $subject);
    return "l'envoi WordPress a échoué (vérifiez la configuration SMTP du site).";
}

function ptimer_send_whatsapp($message) {
    $to = preg_replace('/[^0-9+]/', '', (string) get_option('ptimer_whatsapp'));
    if (!$to) {
        ptimer_log('WhatsApp', 'ÉCHEC — numéro WhatsApp manquant.');
        return 'numéro WhatsApp manquant.';
    }

    $method = get_option('ptimer_wa_method', 'callmebot');

    if ($method === 'cloud') {
        $token   = get_option('ptimer_wa_token');
        $phoneid = get_option('ptimer_wa_phone_id');
        if (!$token || !$phoneid) {
            ptimer_log('WhatsApp', 'ÉCHEC — configuration Cloud API incomplète.');
            return 'configuration Cloud API incomplète (token + Phone Number ID requis).';
        }
        $response = wp_remote_post('https://graph.facebook.com/v19.0/' . rawurlencode($phoneid) . '/messages', array(
            'timeout' => 20,
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode(array(
                'messaging_product' => 'whatsapp',
                'to'   => ltrim($to, '+'),
                'type' => 'text',
                'text' => array('preview_url' => false, 'body' => $message),
            )),
        ));
    } else {
        $apikey = get_option('ptimer_wa_apikey');
        if (!$apikey) {
            ptimer_log('WhatsApp', 'ÉCHEC — clé API CallMeBot manquante.');
            return 'clé API CallMeBot manquante.';
        }
        $url = 'https://api.callmebot.com/whatsapp.php?phone=' . urlencode($to)
             . '&text=' . urlencode($message)
             . '&apikey=' . urlencode($apikey);
        $response = wp_remote_get($url, array('timeout' => 20));
    }

    if (is_wp_error($response)) {
        ptimer_log('WhatsApp', 'ÉCHEC — ' . $response->get_error_message());
        return $response->get_error_message();
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    if ($code >= 200 && $code < 300) {
        ptimer_log('WhatsApp', 'Envoyé au ' . $to . ' (HTTP ' . $code . ')');
        return true;
    }
    ptimer_log('WhatsApp', 'ÉCHEC — réponse HTTP ' . $code);
    return 'réponse HTTP ' . $code . ' de la passerelle WhatsApp.';
}

/* ============================================================
   7. VÉRIFICATION QUOTIDIENNE + ALERTES J-90 / J-30 / J-15 / J-7
   ============================================================ */

add_action('ptimer_daily_check', 'ptimer_run_daily_check');

function ptimer_run_daily_check() {
    $days = ptimer_days_left();
    if ($days === null) return;

    $thresholds = array(90, 30, 15, 7, 0);
    $notified   = get_option('ptimer_notified', array());

    foreach ($thresholds as $t) {
        if ($days <= $t && empty($notified[$t])) {
            ptimer_dispatch_alert($t, $days);
            $notified[$t] = current_time('mysql');
            update_option('ptimer_notified', $notified);
        }
    }
}

function ptimer_dispatch_alert($threshold, $days) {
    $titles = array(
        90 => 'Rappel — renouvellement dans 3 mois',
        30 => 'Alerte — renouvellement dans 1 mois',
        15 => 'Alerte — renouvellement dans 15 jours',
        7  => 'URGENT — renouvellement dans 1 semaine',
        0  => 'ALERTE ROUGE — hébergement expiré',
    );
    $title = isset($titles[$threshold]) ? $titles[$threshold] : 'Notification hébergement';

    $end  = ptimer_fmt_date(ptimer_end_ts());
    $site = get_bloginfo('name');
    $j    = max(0, $days);

    $txt = "🛰️ ELEVEN TIMER — SURVEILLANCE HEBERGEMENT\n\n"
         . $title . "\n\n"
         . "Site : " . $site . "\n"
         . "Date d'expiration : " . $end . "\n"
         . "Temps restant : " . $j . " jour(s)\n\n"
         . "Pensez à renouveler votre abonnement d'hebergement.";

    $html = '<p style="font-size:16px;color:#e8c96a;margin:0 0 14px;"><strong>' . esc_html($title) . '</strong></p>'
          . '<p>Site : <strong>' . esc_html($site) . '</strong></p>'
          . "<p>Date d'expiration : <strong>" . esc_html($end) . '</strong></p>'
          . '<p>Temps restant estimé : <strong>' . $j . ' jour(s)</strong></p>'
          . '<p style="margin-top:16px;">Pensez à renouveler votre abonnement d\'hébergement dès que possible.</p>';

    $subject = '⏳ [Eleven Timer] ' . $title . ($j > 0 ? ' — J-' . $j : '');
    ptimer_send_email($subject, $html);
    ptimer_send_whatsapp($txt);
}

/* ============================================================
   8. BARRE D'ADMINISTRATION WP (JOURS RESTANTS)
   ============================================================ */

add_action('admin_bar_menu', function ($bar) {
    if (!current_user_can('manage_options')) return;
    $days = ptimer_days_left();
    if ($days === null) return;
    $st = ptimer_status($days);
    $label = $days > 0 ? '⏳ ' . $days . ' j' : '⚠ Expiré';
    $bar->add_node(array(
        'id'    => 'ptimer-node',
        'title' => '<span style="color:' . esc_attr($st['color']) . ';font-weight:bold;">' . esc_html($label) . '</span>',
        'href'  => admin_url('admin.php?page=eleven_timer'),
        'meta'  => array('title' => 'Eleven Timer — ' . $st['label']),
    ));
}, 100);

/* ============================================================
   9. PAGE RÉGLAGES PRINCIPALE
   ============================================================ */

function ptimer_admin_styles() {
    echo '<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&display=swap" rel="stylesheet">';
    echo '<style>
    .ptw{max-width:1080px;}
    .ptw-card{background:#12162b;border:1px solid #2a3153;border-radius:14px;padding:22px 24px;margin-top:18px;color:#d7dbe8;}
    .ptw-card h2{margin:0 0 4px;color:#e8c96a;font-size:14px;letter-spacing:1px;text-transform:uppercase;font-family:"Orbitron",sans-serif;}
    .ptw-card .desc{color:#8fa3c8;font-size:12px;margin:0 0 16px;}
    .ptw-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px;}
    .ptw-field label{display:block;font-size:10px;letter-spacing:1px;color:#9aa6c4;margin-bottom:6px;text-transform:uppercase;}
    .ptw-field input[type=date],.ptw-field input[type=text],.ptw-field input[type=email],.ptw-field input[type=password],.ptw-field select{width:100%;background:#0b0e1f;border:1px solid #2c3560;border-radius:8px;padding:10px 12px;color:#fff;font-size:13px;box-sizing:border-box;}
    .ptw-field input:focus,.ptw-field select:focus{border-color:#e8c96a;outline:none;box-shadow:0 0 0 2px rgba(232,201,106,.15);}
    .ptw-check{display:flex;align-items:center;gap:8px;font-size:12px;color:#c7cfe4;margin-top:4px;}
    .ptw-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px;}
    .btn-pt{cursor:pointer;border-radius:8px;padding:11px 20px;font-size:12px;font-weight:700;letter-spacing:1px;border:1px solid transparent;transition:.25s;}
    .btn-pt.primary{background:linear-gradient(135deg,#caa23f,#a47b3b);color:#141414;}
    .btn-pt.primary:hover{filter:brightness(1.12);box-shadow:0 0 14px rgba(232,201,106,.45);}
    .btn-pt.ghost{background:transparent;border-color:#3a4370;color:#bcd0ff;}
    .btn-pt.ghost:hover{border-color:#e8c96a;color:#e8c96a;}
    .btn-pt.danger{background:transparent;border-color:#7a3030;color:#ff8f8f;}
    .btn-pt.danger:hover{border-color:#ff5d5d;color:#ff5d5d;}
    .ptw-flash{margin-top:16px;padding:12px 16px;border-radius:10px;font-size:13px;}
    .ptw-flash.ok{background:#0f2a1c;border:1px solid #2e7d4f;color:#9fe6bd;}
    .ptw-flash.err{background:#2a1214;border:1px solid #7a3030;color:#ffb3b3;}
    .ptw-log{width:100%;border-collapse:collapse;font-size:12px;}
    .ptw-log th,.ptw-log td{padding:8px 10px;border-bottom:1px solid #232a4a;text-align:left;}
    .ptw-log th{color:#8fa3c8;font-weight:600;font-size:10px;letter-spacing:1px;text-transform:uppercase;}
    .ptw-hero{display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;}
    .ptw-count{display:flex;gap:8px;flex-wrap:wrap;}
    .ptw-count .u{background:#0b0e1f;border:1px solid #2c3560;border-radius:10px;padding:10px 14px;text-align:center;min-width:64px;}
    .ptw-count .u b{display:block;font-size:24px;color:#eaf6ff;font-family:Consolas,monospace;}
    .ptw-count .u span{font-size:9px;letter-spacing:2px;color:#8fa3c8;}
    .ptw-pill{padding:5px 14px;border-radius:999px;font-size:11px;letter-spacing:2px;border:1px solid currentColor;font-weight:700;display:inline-block;}
    .ptw-hint{font-size:11px;color:#8fa3c8;line-height:1.7;background:#0b0e1f;border:1px dashed #2c3560;border-radius:8px;padding:10px 14px;margin-top:12px;}
    </style>';
}

function ptimer_render_settings_page() {
    if (!current_user_can('manage_options')) return;

    $flash      = ptimer_flash_get();
    $start      = get_option('ptimer_start_date', '');
    $end        = get_option('ptimer_end_date', '');
    $email      = get_option('ptimer_email', get_option('admin_email'));
    $wa         = get_option('ptimer_whatsapp', '');
    $method     = get_option('ptimer_wa_method', 'callmebot');
    $token      = get_option('ptimer_wa_token', '');
    $pid        = get_option('ptimer_wa_phone_id', '');
    $apikey     = get_option('ptimer_wa_apikey', '');
    $showf      = (int) get_option('ptimer_show_frontend', 1);
    $admonly    = (int) get_option('ptimer_admins_only', 0);
    $log        = get_option('ptimer_log', array());
    $days       = ptimer_days_left();
    $st         = ptimer_status($days);
    $notified   = get_option('ptimer_notified', array());

    ptimer_admin_styles();
    ?>
    <div class="wrap ptw">
        <h1 style="color:#e8c96a;font-family:'Orbitron',sans-serif;">🕰️ ELEVEN TIMER — SURVEILLANCE HÉBERGEMENT</h1>

        <?php if ($flash) : ?>
            <div class="ptw-flash <?php echo esc_attr($flash['type']); ?>"><?php echo esc_html($flash['msg']); ?></div>
        <?php endif; ?>

        <div class="ptw-card">
            <h2>État de l'abonnement</h2>
            <p class="desc">Compte à rebours en temps réel de votre hébergement.</p>
            <div class="ptw-hero">
                <div>
                    <span class="ptw-pill" style="color:<?php echo esc_attr($st['color']); ?>;"><?php echo esc_html($st['label']); ?></span>
                    <p style="margin:12px 0 0;font-size:12px;color:#8fa3c8;">
                        Début : <strong style="color:#c7cfe4;"><?php echo esc_html(ptimer_fmt_date(ptimer_start_ts())); ?></strong>
                        &nbsp;•&nbsp; Fin : <strong style="color:#c7cfe4;"><?php echo esc_html(ptimer_fmt_date(ptimer_end_ts())); ?></strong>
                    </p>
                </div>
                <div class="ptw-count" id="ptw-live" data-end="<?php echo esc_attr(ptimer_end_ts()); ?>">
                    <div class="u"><b id="ptw-d">--</b><span>JOURS</span></div>
                    <div class="u"><b id="ptw-h">--</b><span>HEURES</span></div>
                    <div class="u"><b id="ptw-m">--</b><span>MINUTES</span></div>
                    <div class="u"><b id="ptw-s">--</b><span>SECONDES</span></div>
                </div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('ptimer_main', 'ptimer_nonce'); ?>
            <input type="hidden" name="ptimer_page" value="main">

            <div class="ptw-card">
                <h2>Dates d'abonnement</h2>
                <p class="desc">Période couverte par votre hébergement actuel.</p>
                <div class="ptw-grid">
                    <div class="ptw-field">
                        <label>Début de l'abonnement</label>
                        <input type="date" name="ptimer_start_date" value="<?php echo esc_attr($start); ?>">
                    </div>
                    <div class="ptw-field">
                        <label>Fin de l'abonnement (expiration)</label>
                        <input type="date" name="ptimer_end_date" value="<?php echo esc_attr($end); ?>" required>
                    </div>
                </div>
            </div>

            <div class="ptw-card">
                <h2>Notifications — rappels J-90, J-30, J-15, J-7</h2>
                <p class="desc">Chaque rappel est envoyé en double : e-mail + WhatsApp.</p>
                <div class="ptw-grid">
                    <div class="ptw-field">
                        <label>E-mail de notification</label>
                        <input type="email" name="ptimer_email" value="<?php echo esc_attr($email); ?>">
                    </div>
                    <div class="ptw-field">
                        <label>Numéro WhatsApp (format international, ex : +213xxxxxxxxx)</label>
                        <input type="text" name="ptimer_whatsapp" value="<?php echo esc_attr($wa); ?>" placeholder="+213XXXXXXXXX">
                    </div>
                    <div class="ptw-field">
                        <label>Passerelle WhatsApp</label>
                        <select name="ptimer_wa_method" id="ptw-method">
                            <option value="callmebot" <?php selected($method, 'callmebot'); ?>>CallMeBot (gratuit, simple)</option>
                            <option value="cloud" <?php selected($method, 'cloud'); ?>>WhatsApp Cloud API (Meta, officiel)</option>
                        </select>
                    </div>
                </div>

                <div id="ptw-callmebot-fields" style="margin-top:14px;">
                    <div class="ptw-grid">
                        <div class="ptw-field">
                            <label>Clé API CallMeBot</label>
                            <input type="text" name="ptimer_wa_apikey" value="<?php echo esc_attr($apikey); ?>" placeholder="ex : 123456">
                        </div>
                    </div>
                    <div class="ptw-hint">
                        📲 <strong>Obtenir une clé CallMeBot gratuitement :</strong> ajoutez le numéro <strong>+34 644 51 95 23</strong> dans vos contacts WhatsApp, envoyez-lui le message
                        <em>"I allow callmebot to send me messages"</em>, puis copiez la clé API reçue en réponse.
                    </div>
                </div>

                <div id="ptw-cloud-fields" style="margin-top:14px;">
                    <div class="ptw-grid">
                        <div class="ptw-field">
                            <label>Access Token (Meta)</label>
                            <input type="text" name="ptimer_wa_token" value="<?php echo esc_attr($token); ?>" placeholder="EAAG...">
                        </div>
                        <div class="ptw-field">
                            <label>Phone Number ID (Meta)</label>
                            <input type="text" name="ptimer_wa_phone_id" value="<?php echo esc_attr($pid); ?>" placeholder="1234567890">
                        </div>
                    </div>
                    <div class="ptw-hint">
                        🔐 Nécessite une application Meta WhatsApp Cloud API (business). Le numéro destinataire doit avoir accepté la conversation.
                    </div>
                </div>
            </div>

            <div class="ptw-card">
                <h2>Affichage &amp; sécurité</h2>
                <p class="desc">Contrôle de l'icône publique et du mot de passe d'accès au timer.</p>
                <div class="ptw-grid">
                    <div>
                        <label class="ptw-check"><input type="checkbox" name="ptimer_show_frontend" value="1" <?php checked($showf, 1); ?>> Afficher l'icône « T » sur le site public</label>
                        <label class="ptw-check"><input type="checkbox" name="ptimer_admins_only" value="1" <?php checked($admonly, 1); ?>> Réserver l'icône aux administrateurs connectés</label>
                    </div>
                    <div class="ptw-grid">
                        <div class="ptw-field">
                            <label>Nouveau mot de passe (laisser vide = inchangé)</label>
                            <input type="password" name="ptimer_pass1" autocomplete="new-password">
                        </div>
                        <div class="ptw-field">
                            <label>Confirmer le mot de passe</label>
                            <input type="password" name="ptimer_pass2" autocomplete="new-password">
                        </div>
                    </div>
                </div>
            </div>

            <div class="ptw-actions">
                <button type="submit" name="ptimer_action" value="save" class="btn-pt primary">💾 ENREGISTRER LES RÉGLAGES</button>
                <button type="submit" name="ptimer_action" value="test_email" class="btn-pt ghost">✉️ TEST E-MAIL</button>
                <button type="submit" name="ptimer_action" value="test_whatsapp" class="btn-pt ghost">📱 TEST WHATSAPP</button>
                <button type="submit" name="ptimer_action" value="run_check" class="btn-pt ghost">▶️ VÉRIFIER MAINTENANT</button>
                <button type="submit" name="ptimer_action" value="reset_flags" class="btn-pt danger">♻️ RÉINITIALISER LES ALERTES</button>
            </div>
        </form>

        <div class="ptw-card">
            <h2>Journal des envois</h2>
            <p class="desc">Historique des alertes et tests (30 derniers événements).</p>
            <?php if (empty($log)) : ?>
                <p style="font-size:12px;color:#8fa3c8;">Aucun événement pour le moment.</p>
            <?php else : ?>
                <table class="ptw-log">
                    <thead><tr><th>Date</th><th>Canal</th><th>Détail</th></tr></thead>
                    <tbody>
                    <?php foreach ($log as $entry) : ?>
                        <tr>
                            <td style="white-space:nowrap;color:#8fa3c8;"><?php echo esc_html(date_i18n('d/m/Y H:i', strtotime($entry['time']))); ?></td>
                            <td style="white-space:nowrap;color:#e8c96a;"><?php echo esc_html($entry['channel']); ?></td>
                            <td><?php echo esc_html($entry['status']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            <?php
            $sent = array();
            foreach (array(90, 30, 15, 7, 0) as $t) {
                if (!empty($notified[$t])) $sent[] = 'J-' . $t;
            }
            ?>
            <p style="margin:14px 0 0;font-size:11px;color:#8fa3c8;">
                Alertes déjà envoyées pour cette échéance :
                <strong style="color:#c7cfe4;"><?php echo $sent ? esc_html(implode(', ', $sent)) : 'aucune'; ?></strong>
            </p>
        </div>
    </div>

    <script>
    (function () {
        var sel = document.getElementById('ptw-method');
        function tog() {
            var v = sel.value;
            document.getElementById('ptw-cloud-fields').style.display = (v === 'cloud') ? 'block' : 'none';
            document.getElementById('ptw-callmebot-fields').style.display = (v === 'callmebot') ? 'block' : 'none';
        }
        sel.addEventListener('change', tog);
        tog();

        var root = document.getElementById('ptw-live');
        if (!root) return;
        var end = parseInt(root.getAttribute('data-end'), 10) * 1000;
        function p(n) { return n < 10 ? '0' + n : '' + n; }
        function up() {
            var diff = end - Date.now();
            if (diff < 0) diff = 0;
            var s = Math.floor(diff / 1000);
            var d = Math.floor(s / 86400); s -= d * 86400;
            var h = Math.floor(s / 3600); s -= h * 3600;
            var m = Math.floor(s / 60); s -= m * 60;
            document.getElementById('ptw-d').textContent = d;
            document.getElementById('ptw-h').textContent = p(h);
            document.getElementById('ptw-m').textContent = p(m);
            document.getElementById('ptw-s').textContent = p(s);
        }
        up();
        setInterval(up, 1000);
    })();
    </script>
    <?php
}

/* ============================================================
   10. ASSISTANT DE CONFIGURATION INITIALE
   ============================================================ */

function ptimer_render_setup_page() {
    if (!current_user_can('manage_options')) return;

    $flash = ptimer_flash_get();
    $start = get_option('ptimer_start_date', '');
    $end   = get_option('ptimer_end_date', '');
    $email = get_option('ptimer_email', get_option('admin_email'));
    $wa    = get_option('ptimer_whatsapp', '');

    ptimer_admin_styles();
    ?>
    <div class="wrap ptw" style="max-width:720px;margin:0 auto;">
        <h1 style="color:#e8c96a;font-family:'Orbitron',sans-serif;text-align:center;">🛰️ BIENVENUE — ELEVEN TIMER</h1>
        <p style="text-align:center;color:#8fa3c8;">Configurez votre abonnement en 30 secondes pour activer la surveillance.</p>

        <?php if ($flash) : ?>
            <div class="ptw-flash <?php echo esc_attr($flash['type']); ?>"><?php echo esc_html($flash['msg']); ?></div>
        <?php endif; ?>

        <form method="post">
            <?php wp_nonce_field('ptimer_setup', 'ptimer_nonce'); ?>
            <input type="hidden" name="ptimer_page" value="setup">
            <input type="hidden" name="ptimer_finish_setup" value="1">

            <div class="ptw-card">
                <h2>1 • Période d'abonnement</h2>
                <div class="ptw-grid">
                    <div class="ptw-field">
                        <label>Début de l'abonnement</label>
                        <input type="date" name="ptimer_start_date" value="<?php echo esc_attr($start ? $start : date('Y-m-d')); ?>">
                    </div>
                    <div class="ptw-field">
                        <label>Fin de l'abonnement (expiration)</label>
                        <input type="date" name="ptimer_end_date" value="<?php echo esc_attr($end); ?>" required>
                    </div>
                </div>
            </div>

            <div class="ptw-card">
                <h2>2 • Contacts de notification</h2>
                <p class="desc">Vous recevrez les rappels J-90, J-30, J-15 et J-7 sur ces canaux.</p>
                <div class="ptw-grid">
                    <div class="ptw-field">
                        <label>E-mail</label>
                        <input type="email" name="ptimer_email" value="<?php echo esc_attr($email); ?>">
                    </div>
                    <div class="ptw-field">
                        <label>WhatsApp (format international)</label>
                        <input type="text" name="ptimer_whatsapp" value="<?php echo esc_attr($wa); ?>" placeholder="+213XXXXXXXXX">
                    </div>
                </div>
                <div class="ptw-hint">
                    ℹ️ La passerelle WhatsApp (CallMeBot ou Cloud API) se configure ensuite dans la page principale du plugin.
                </div>
            </div>

            <div class="ptw-actions" style="justify-content:center;">
                <button type="submit" name="ptimer_action" value="save" class="btn-pt primary">🚀 ACTIVER LA SURVEILLANCE</button>
            </div>
        </form>
    </div>
    <?php
}

/* ============================================================
   11. WIDGET PUBLIC : ICÔNE T + MOT DE PASSE + TIMER FUTURISTE
   ============================================================ */

add_action('wp_footer', 'ptimer_frontend_widget');

function ptimer_frontend_widget() {
    if (!get_option('ptimer_show_frontend', 1)) return;
    if (get_option('ptimer_admins_only') && !current_user_can('manage_options')) return;
    if (!get_option('ptimer_end_date')) return;

    $ajax  = esc_url(admin_url('admin-ajax.php'));
    $nonce = esc_js(wp_create_nonce('ptimer_nonce'));
    $site  = esc_html(get_bloginfo('name'));
    ?>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&display=swap" rel="stylesheet">
    <style>
    #ptimer-badge{position:fixed;bottom:12px;right:12px;width:24px;height:24px;border-radius:50%;background:rgba(10,13,26,.55);border:1px solid rgba(232,201,106,.4);color:#e8c96a;font-family:'Orbitron',monospace;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;z-index:999998;cursor:pointer;opacity:.3;transition:.3s;backdrop-filter:blur(3px);user-select:none;}
    #ptimer-badge:hover{opacity:1;transform:scale(1.2);box-shadow:0 0 14px rgba(232,201,106,.65);}
    @media(max-width:600px){#ptimer-badge{width:20px;height:20px;font-size:9px;bottom:10px;right:10px;}}

    .ptimer-modal{position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:rgba(3,5,14,.92);backdrop-filter:blur(6px);opacity:0;visibility:hidden;transition:.35s ease;}
    .ptimer-modal.is-open{opacity:1;visibility:visible;}

    .ptimer-pwd-box{position:relative;width:min(340px,92vw);background:linear-gradient(160deg,#10142a,#181f3d);border:1px solid rgba(202,162,63,.5);border-radius:16px;padding:30px 26px;text-align:center;font-family:'Orbitron','Segoe UI',monospace;color:#eaf0ff;box-shadow:0 0 50px rgba(202,162,63,.15);transform:scale(.94);transition:.3s;}
    .ptimer-modal.is-open .ptimer-pwd-box{transform:none;}
    .ptimer-pwd-icon{font-size:30px;}
    .ptimer-pwd-box h3{margin:10px 0 6px;font-size:15px;letter-spacing:3px;color:#e8c96a;}
    .ptimer-pwd-box p{font-size:11px;color:#9aa6c4;line-height:1.6;margin:0 0 16px;font-family:'Segoe UI',Arial,sans-serif;}
    #ptimer-pwd-input{width:100%;box-sizing:border-box;background:#0b0e1f;border:1px solid #2c3560;border-radius:8px;padding:12px;color:#fff;font-size:15px;text-align:center;letter-spacing:3px;outline:none;transition:.25s;}
    #ptimer-pwd-input:focus{border-color:#e8c96a;box-shadow:0 0 12px rgba(232,201,106,.35);}
    #ptimer-pwd-btn{width:100%;margin-top:14px;background:linear-gradient(135deg,#caa23f,#a47b3b);border:none;border-radius:8px;padding:12px;color:#141414;font-weight:700;font-size:12px;letter-spacing:2px;cursor:pointer;transition:.25s;font-family:inherit;}
    #ptimer-pwd-btn:hover{filter:brightness(1.15);box-shadow:0 0 16px rgba(232,201,106,.5);}
    #ptimer-pwd-btn:disabled{opacity:.5;cursor:not-allowed;}
    #ptimer-pwd-msg{min-height:16px;margin-top:10px;font-size:10px;color:#ff7676;letter-spacing:1px;}
    .ptimer-shake{animation:ptshake .4s;}
    @keyframes ptshake{0%,100%{transform:translateX(0);}20%{transform:translateX(-8px);}40%{transform:translateX(8px);}60%{transform:translateX(-5px);}80%{transform:translateX(5px);}}

    .ptimer-x{position:absolute;top:8px;right:12px;background:none;border:none;color:#8fa3c8;font-size:22px;cursor:pointer;line-height:1;z-index:2;}
    .ptimer-x:hover{color:#fff;}

    .ptimer-stars{position:absolute;top:0;left:0;right:0;bottom:0;overflow:hidden;pointer-events:none;}
    .ptimer-stars span{position:absolute;background:#fff;border-radius:50%;opacity:.1;animation:pttwinkle linear infinite;}
    @keyframes pttwinkle{0%,100%{opacity:.05;}50%{opacity:.9;}}

    .ptimer-card{position:relative;width:min(700px,94vw);max-height:94vh;overflow:auto;background:linear-gradient(160deg,#0d1122,#161c36 55%,#0d1122);border:1px solid rgba(202,162,63,.45);border-radius:18px;padding:34px 34px 22px;text-align:center;font-family:'Orbitron','Segoe UI',monospace;color:#eaf0ff;box-shadow:0 0 60px rgba(64,140,255,.15),0 0 120px rgba(202,162,63,.08),inset 0 0 40px rgba(10,14,30,.8);transform:translateY(24px) scale(.96);transition:.4s cubic-bezier(.2,.9,.25,1.2);}
    .ptimer-modal.is-open .ptimer-card{transform:none;}
    .ptimer-card::before,.ptimer-card::after{content:'';position:absolute;width:26px;height:26px;border-color:#e8c96a;border-style:solid;}
    .ptimer-card::before{top:-1px;left:-1px;border-width:2px 0 0 2px;border-radius:18px 0 0 0;}
    .ptimer-card::after{bottom:-1px;right:-1px;border-width:0 2px 2px 0;border-radius:0 0 18px 0;}

    .ptimer-reactor{position:relative;width:74px;height:74px;margin:0 auto 10px;}
    .ptimer-reactor .ring{position:absolute;top:0;left:0;right:0;bottom:0;border-radius:50%;border:2px dashed rgba(232,201,106,.55);}
    .ptimer-reactor .r1{animation:ptspin 9s linear infinite;}
    .ptimer-reactor .r2{top:10px;left:10px;right:10px;bottom:10px;border-color:rgba(126,240,255,.5);animation:ptspin 6s linear infinite reverse;}
    .ptimer-reactor .core{position:absolute;top:28px;left:28px;right:28px;bottom:28px;border-radius:50%;background:radial-gradient(circle,#bff3ff,#39c6ff 55%,rgba(57,198,255,0));box-shadow:0 0 18px #39c6ff;animation:ptpulse 2.2s ease-in-out infinite;}
    @keyframes ptspin{to{transform:rotate(360deg);}}
    @keyframes ptpulse{0%,100%{transform:scale(1);opacity:.85;}50%{transform:scale(1.25);opacity:1;}}

    .ptimer-sub{font-size:9px;letter-spacing:4px;color:#8fa3c8;}
    .ptimer-head h2{margin:6px 0 0;font-size:clamp(15px,3vw,21px);letter-spacing:3px;color:#fff;text-shadow:0 0 20px rgba(232,201,106,.4);}
    .ptimer-statusline{display:flex;justify-content:center;align-items:center;gap:12px;margin-top:14px;flex-wrap:wrap;}
    .ptimer-pill{display:inline-block;padding:5px 14px;border-radius:999px;font-size:10px;letter-spacing:2px;border:1px solid currentColor;font-weight:700;}
    #ptimer-site{font-size:10px;color:#8fa3c8;letter-spacing:1px;}

    .ptimer-grid{display:flex;justify-content:center;align-items:flex-end;gap:6px;margin:20px 0 6px;}
    .ptimer-grid .unit{min-width:70px;}
    .ptimer-grid .val{font-size:clamp(30px,7vw,56px);font-weight:900;line-height:1;color:#eaf6ff;text-shadow:0 0 18px rgba(126,240,255,.55);}
    .ptimer-grid .lbl{font-size:9px;letter-spacing:3px;color:#8fa3c8;margin-top:8px;}
    .ptimer-grid .sep{font-size:clamp(22px,5vw,40px);color:#e8c96a;padding-bottom:22px;opacity:.8;}

    .ptimer-card.lvl-ok .val{text-shadow:0 0 18px rgba(87,227,137,.65);}
    .ptimer-card.lvl-warn .val{text-shadow:0 0 18px rgba(255,215,106,.65);}
    .ptimer-card.lvl-alert .val{text-shadow:0 0 18px rgba(255,161,74,.75);}
    .ptimer-card.lvl-crit .val{text-shadow:0 0 22px rgba(255,93,93,.85);}
    .ptimer-card.expired .val{color:#ff5d5d;text-shadow:0 0 22px rgba(255,93,93,.9);animation:ptblink 1s steps(2) infinite;}
    @keyframes ptblink{50%{opacity:.35;}}

    .ptimer-progress{height:8px;border-radius:99px;background:#1c2340;border:1px solid #2a3153;overflow:hidden;margin:16px 0 8px;}
    .ptimer-progress .bar{height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,#39c6ff,#e8c96a);box-shadow:0 0 12px rgba(57,198,255,.7);transition:width .6s ease;}
    .ptimer-meta{display:flex;justify-content:space-between;gap:10px;font-size:9px;letter-spacing:1px;color:#8fa3c8;flex-wrap:wrap;}
    .ptimer-foot{margin-top:18px;padding-top:12px;border-top:1px solid #232a4a;font-size:8px;letter-spacing:3px;color:#5d6785;}

    @media(max-width:520px){
        .ptimer-card{padding:26px 14px 16px;}
        .ptimer-grid .unit{min-width:56px;}
        .ptimer-grid .sep{padding-bottom:16px;}
    }
    </style>

    <div id="ptimer-badge" title="Timer hébergement">T</div>

    <div id="ptimer-pwd-modal" class="ptimer-modal">
        <div class="ptimer-pwd-box" id="ptimer-pwd-box">
            <button class="ptimer-x" data-ptimer-close>&times;</button>
            <div class="ptimer-pwd-icon">🔒</div>
            <h3>ACCÈS SÉCURISÉ</h3>
            <p>Zone réservée au propriétaire du site.<br>Entrez le mot de passe pour afficher le timer.</p>
            <input type="password" id="ptimer-pwd-input" placeholder="••••••••••" autocomplete="off">
            <div id="ptimer-pwd-msg"></div>
            <button id="ptimer-pwd-btn">AUTHENTIFIER</button>
        </div>
    </div>

    <div id="ptimer-timer-modal" class="ptimer-modal">
        <div class="ptimer-stars" id="ptimer-stars"></div>
        <div class="ptimer-card lvl-ok" id="ptimer-card">
            <button class="ptimer-x" data-ptimer-close>&times;</button>
            <div class="ptimer-reactor"><span class="ring r1"></span><span class="ring r2"></span><span class="core"></span></div>
            <div class="ptimer-head">
                <div class="ptimer-sub">ELEVEN TIMER • SYSTÈME DE SURVEILLANCE</div>
                <h2>SURVEILLANCE D'HÉBERGEMENT</h2>
            </div>
            <div class="ptimer-statusline">
                <span id="ptimer-pill" class="ptimer-pill" style="color:#57e389;">—</span>
                <span id="ptimer-site"><?php echo $site; ?></span>
            </div>
            <div class="ptimer-grid">
                <div class="unit"><div class="val" id="ptimer-d">--</div><div class="lbl">JOURS</div></div>
                <div class="sep">:</div>
                <div class="unit"><div class="val" id="ptimer-h">--</div><div class="lbl">HEURES</div></div>
                <div class="sep">:</div>
                <div class="unit"><div class="val" id="ptimer-m">--</div><div class="lbl">MINUTES</div></div>
                <div class="sep">:</div>
                <div class="unit"><div class="val" id="ptimer-s">--</div><div class="lbl">SECONDES</div></div>
            </div>
            <div class="ptimer-progress"><div class="bar" id="ptimer-bar"></div></div>
            <div class="ptimer-meta">
                <span id="ptimer-bar-label">—</span>
                <span>Début : <?php echo esc_html(ptimer_fmt_date(ptimer_start_ts())); ?> • Fin : <?php echo esc_html(ptimer_fmt_date(ptimer_end_ts())); ?></span>
            </div>
            <div class="ptimer-foot">SYSTÈME ELEVEN TIMER • ACCÈS VÉRIFIÉ ✓</div>
        </div>
    </div>

    <script>
    (function () {
        var AJAX = '<?php echo $ajax; ?>';
        var NONCE = '<?php echo $nonce; ?>';

        var badge = document.getElementById('ptimer-badge');
        var pwdModal = document.getElementById('ptimer-pwd-modal');
        var timerModal = document.getElementById('ptimer-timer-modal');
        var pwdBox = document.getElementById('ptimer-pwd-box');
        var input = document.getElementById('ptimer-pwd-input');
        var msg = document.getElementById('ptimer-pwd-msg');
        var btn = document.getElementById('ptimer-pwd-btn');
        var timerId = null;

        function open(m) { m.classList.add('is-open'); }
        function close(m) {
            m.classList.remove('is-open');
            if (m === timerModal && timerId) { clearInterval(timerId); timerId = null; }
        }

        badge.addEventListener('click', function () {
            msg.textContent = '';
            input.value = '';
            btn.disabled = false;
            open(pwdModal);
            setTimeout(function () { input.focus(); }, 200);
        });

        Array.prototype.forEach.call(document.querySelectorAll('[data-ptimer-close]'), function (b) {
            b.addEventListener('click', function () { close(b.closest('.ptimer-modal')); });
        });

        [pwdModal, timerModal].forEach(function (m) {
            m.addEventListener('click', function (e) { if (e.target === m) close(m); });
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') { close(pwdModal); close(timerModal); }
        });

        function pad(n) { return n < 10 ? '0' + n : '' + n; }

        function tick(data) {
            var card = document.getElementById('ptimer-card');
            var pill = document.getElementById('ptimer-pill');
            var now = Date.now();
            var end = data.end_ts * 1000;
            var diff = end - now;
            var elD = document.getElementById('ptimer-d');
            var elH = document.getElementById('ptimer-h');
            var elM = document.getElementById('ptimer-m');
            var elS = document.getElementById('ptimer-s');

            if (diff <= 0) {
                elD.textContent = '0'; elH.textContent = '00'; elM.textContent = '00'; elS.textContent = '00';
                card.classList.add('expired');
                card.classList.remove('lvl-ok', 'lvl-warn', 'lvl-alert', 'lvl-crit');
                pill.textContent = '⚠ EXPIRÉ';
                pill.style.color = '#ff5d5d';
                document.getElementById('ptimer-bar').style.width = '100%';
                document.getElementById('ptimer-bar-label').textContent = '100% consommé';
                return;
            }
            card.classList.remove('expired');

            var s = Math.floor(diff / 1000);
            var d = Math.floor(s / 86400); s -= d * 86400;
            var h = Math.floor(s / 3600); s -= h * 3600;
            var m = Math.floor(s / 60); s -= m * 60;

            elD.textContent = d;
            elH.textContent = pad(h);
            elM.textContent = pad(m);
            elS.textContent = pad(s);

            card.classList.remove('lvl-ok', 'lvl-warn', 'lvl-alert', 'lvl-crit');
            var lvl = d <= 7 ? 'lvl-crit' : d <= 30 ? 'lvl-alert' : d <= 90 ? 'lvl-warn' : 'lvl-ok';
            card.classList.add(lvl);

            var map = {
                'lvl-ok': ['✔ OPÉRATIONNEL', '#57e389'],
                'lvl-warn': ['◐ ATTENTION', '#ffd76a'],
                'lvl-alert': ['▲ ALERTE', '#ffa14a'],
                'lvl-crit': ['● CRITIQUE', '#ff5d5d']
            };
            pill.textContent = map[lvl][0];
            pill.style.color = map[lvl][1];

            var st = data.start_ts * 1000;
            var pct = (st && end > st) ? Math.min(100, Math.max(0, (now - st) / (end - st) * 100)) : 0;
            document.getElementById('ptimer-bar').style.width = pct + '%';
            document.getElementById('ptimer-bar-label').textContent = pct.toFixed(1) + '% consommé';
        }

        function buildStars() {
            var c = document.getElementById('ptimer-stars');
            if (c.getAttribute('data-done')) return;
            c.setAttribute('data-done', '1');
            for (var i = 0; i < 90; i++) {
                var sp = document.createElement('span');
                sp.style.left = (Math.random() * 100) + '%';
                sp.style.top = (Math.random() * 100) + '%';
                var sz = Math.random() * 2 + 1;
                sp.style.width = sz + 'px';
                sp.style.height = sz + 'px';
                sp.style.animationDuration = (Math.random() * 3 + 2) + 's';
                sp.style.animationDelay = (Math.random() * 4) + 's';
                c.appendChild(sp);
            }
        }

        function submitPwd() {
            var pwd = input.value;
            if (!pwd) { input.focus(); return; }
            btn.disabled = true;
            msg.textContent = '';

            fetch(AJAX, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ action: 'ptimer_verify', nonce: NONCE, password: pwd })
            })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                btn.disabled = false;
                if (res.success) {
                    close(pwdModal);
                    buildStars();
                    open(timerModal);
                    var data = res.data;
                    clearInterval(timerId);
                    tick(data);
                    timerId = setInterval(function () { tick(data); }, 1000);
                } else {
                    msg.textContent = res.data.message;
                    pwdBox.classList.remove('ptimer-shake');
                    void pwdBox.offsetWidth;
                    pwdBox.classList.add('ptimer-shake');
                    if (res.data.locked) btn.disabled = true;
                    input.value = '';
                    input.focus();
                }
            })
            .catch(function () {
                btn.disabled = false;
                msg.textContent = 'Erreur réseau, réessayez.';
            });
        }

        btn.addEventListener('click', submitPwd);
        input.addEventListener('keydown', function (e) { if (e.key === 'Enter') submitPwd(); });
    })();
    </script>
    <?php
}

/* ============================================================
   12. AJAX — VÉRIFICATION DU MOT DE PASSE (CÔTÉ SERVEUR)
   ============================================================ */

add_action('wp_ajax_ptimer_verify', 'ptimer_ajax_verify');
add_action('wp_ajax_nopriv_ptimer_verify', 'ptimer_ajax_verify');

function ptimer_ajax_verify() {
    check_ajax_referer('ptimer_nonce', 'nonce');

    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', $_SERVER['REMOTE_ADDR']) : 'unknown';
    $attempt_key = 'ptimer_att_' . md5($ip);
    $attempts = (int) get_transient($attempt_key);

    if ($attempts >= 5) {
        wp_send_json_error(array(
            'message' => 'Trop de tentatives. Accès bloqué 15 minutes.',
            'locked'  => true,
        ));
    }

    $pwd  = isset($_POST['password']) ? wp_unslash($_POST['password']) : '';
    $hash = get_option('ptimer_password');

    if (!$hash || !wp_check_password($pwd, $hash)) {
        set_transient($attempt_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
        $left = 4 - $attempts;
        wp_send_json_error(array(
            'message' => 'Mot de passe incorrect.' . ($left > 0 ? ' Tentatives restantes : ' . $left : ''),
        ));
    }

    delete_transient($attempt_key);

    wp_send_json_success(array(
        'end_ts'   => ptimer_end_ts(),
        'start_ts' => ptimer_start_ts(),
        'site'     => get_bloginfo('name'),
    ));
}
