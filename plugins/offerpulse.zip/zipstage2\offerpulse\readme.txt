=== OfferPulse ===
Contributors: gafsiabdeldjalil
Tags: offres, promotions, popup, flottant, marketing, countdown
Requires at least: 5.0
Tested up to: 7.1
Requires PHP: 7.0
Stable tag: 1.1.0
License: GPLv2 or later

Offres spéciales futuristes : icône flottante déplaçable et anti-collision, popup premium aux couleurs de votre marque. Interface bilingue automatique : français ou anglais selon la langue du site.

== Description ==

OfferPulse affiche vos offres spéciales dans une icône flottante élégante qui ne gêne jamais la navigation :

* Icône orbite futuriste animée (anneau rotatif, halo pulsant)
* Déplaçable par le visiteur — position mémorisée
* Anti-collision intelligente : s'empile au-dessus des autres widgets (chats…)
* Se masque au défilement descendant, revient à la remontée
* Popup premium : nom de votre entreprise, sous-titre, compte à rebours J-x par offre
* Offres illimitées avec images de la bibliothèque médias, liens et dates d'expiration
* Couleur d'accent personnalisable (thème de toute votre marque)
* Position : bas droite, bas gauche ou bas centre
* Accessible (clavier, ESC, prefers-reduced-motion) et 100 % vanilla JS

== Installation ==

1. Extensions → Ajouter → Téléverser → offerpulse.zip → Activer.
2. Menu « Offres … » dans l'admin : nom d'entreprise, position, couleur.
3. Ajoutez vos offres (image + lien + date d'expiration).

Si l'ancien plugin « Provence Tour Offres Dynamiques » était installé, ses offres sont importées automatiquement.

== Changelog ==

= 1.1.0 =
* Interface bilingue automatique FR / EN : administration, popup public et comptes à rebours (J- devient D- en anglais) — sans aucun réglage.

= 1.0.0 =
* Version initiale : icône orbite, glisser-déposer mémorisé, anti-collision, auto-hide au scroll, popup premium, comptes à rebours, migration depuis Provence Tour Offres Dynamiques.
