<?php
/*
Plugin Name: OfferPulse
Plugin URI: https://www.provencetour-dz.com/
Description: Futuristic special offers: elegant draggable floating icon, smart anti-collision, per-offer countdown, premium branded popup. Works everywhere, never obstructs the display.
Version: 1.1.0
Requires at least: 5.0
Requires PHP: 7.0
Author: Gafsi Abdeldjalil
Author URI: https://www.provencetour-dz.com/
Text Domain: offerpulse
*/

if (!defined('ABSPATH')) exit;

define('OFP_VERSION', '1.1.0');

/* ============================================================
   0. BILINGUE AUTOMATIQUE FR / EN
   ============================================================ */

function ofp_lang() {
    $loc = function_exists('get_locale') ? get_locale() : 'en_US';
    return (strpos($loc, 'fr') === 0) ? 'fr' : 'en';
}

function ofp_t($fr, $en) {
    return ofp_lang() === 'fr' ? $fr : $en;
}

/* ============================================================
   1. ACTIVATION / DÉSACTIVATION / DÉSINSTALLATION
   ============================================================ */

function ofp_defaults() {
    return array(
        'biz_name'       => '',
        'tagline'        => '',
        'position'       => 'br',
        'accent'         => '#e8c96a',
        'draggable'      => 1,
        'autohide'       => 1,
        'smart_avoid'    => 1,
        'btn_label'      => 'OFFRE',
        'popup_note'     => '',
    );
}

function ofp_activate() {
    $existing = get_option('ofp_settings');
    if (!$existing) {
        add_option('ofp_settings', ofp_defaults());
    }
    add_option('ofp_offers', array());
}

function ofp_deactivate() {
}

function ofp_uninstall() {
    delete_option('ofp_settings');
    delete_option('ofp_offers');
    delete_option('ofp_migrated_pto');
}
register_activation_hook(__FILE__, 'ofp_activate');
register_deactivation_hook(__FILE__, 'ofp_deactivate');
if (file_exists(__FILE__)) {
    register_uninstall_hook(__FILE__, 'ofp_uninstall');
}

/* ============================================================
   2. MIGRATION DEPUIS L'ANCIEN PLUGIN PROVENCE TOUR
   ============================================================ */

add_action('admin_init', 'ofp_maybe_migrate');

function ofp_maybe_migrate() {
    if (get_option('ofp_migrated_pto')) return;
    $old = get_option('pto_dynamic_offers');
    if (!empty($old) && is_array($old)) {
        $offers = get_option('ofp_offers', array());
        if (empty($offers)) {
            $clean = array();
            foreach ($old as $o) {
                if (empty($o['image'])) continue;
                $clean[] = array(
                    'image'   => esc_url_raw($o['image']),
                    'link'    => isset($o['link']) ? esc_url_raw($o['link']) : '',
                    'expires' => isset($o['expires']) ? sanitize_text_field($o['expires']) : '',
                );
            }
            update_option('ofp_offers', $clean);
        }
        $s = wp_parse_args(get_option('ofp_settings', array()), ofp_defaults());
        if (empty($s['biz_name'])) {
            $s['biz_name'] = 'Provence Tour';
            $s['btn_label'] = 'OFFRE';
            update_option('ofp_settings', $s);
        }
    }
    update_option('ofp_migrated_pto', 1);
}

/* ============================================================
   3. OUTILS
   ============================================================ */

function ofp_settings() {
    return wp_parse_args(get_option('ofp_settings', array()), ofp_defaults());
}

function ofp_offers() {
    $offers = get_option('ofp_offers', array());
    return is_array($offers) ? $offers : array();
}

function ofp_flash_set($msg, $type = 'ok') {
    set_transient('ofp_flash', array('msg' => $msg, 'type' => $type), 60);
}

function ofp_flash_get() {
    $f = get_transient('ofp_flash');
    if ($f) delete_transient('ofp_flash');
    return $f;
}

function ofp_positions() {
    return array(
        'br' => ofp_t('Bas droite (recommandé)', 'Bottom right (recommended)'),
        'bl' => ofp_t('Bas gauche', 'Bottom left'),
        'bc' => ofp_t('Bas centre', 'Bottom center'),
    );
}

/* ============================================================
   4. MENU ADMIN
   ============================================================ */

add_action('admin_menu', 'ofp_menu');

function ofp_menu() {
    $s = ofp_settings();
    $label = $s['biz_name'] !== '' ? sprintf(ofp_t('Offres %s', 'Offers — %s'), $s['biz_name']) : 'OfferPulse';
    add_menu_page(
        'OfferPulse',
        $label,
        'manage_options',
        'offerpulse',
        'ofp_admin_page',
        'dashicons-megaphone',
        60
    );
}

/* ============================================================
   5. TRAITEMENT DU FORMULAIRE
   ============================================================ */

add_action('admin_init', 'ofp_handle_save');

function ofp_handle_save() {
    if (!is_admin() || !current_user_can('manage_options')) return;
    if (!isset($_POST['ofp_action'])) return;
    if (!isset($_POST['ofp_nonce']) || !wp_verify_nonce($_POST['ofp_nonce'], 'ofp_save')) {
        wp_die(ofp_t('Vérification de sécurité échouée.', 'Security check failed.'));
    }

    $act = sanitize_key(wp_unslash($_POST['ofp_action']));

    if ($act === 'save_settings') {
        $in = ofp_defaults();
        $in['biz_name']    = isset($_POST['ofp_biz_name']) ? sanitize_text_field(wp_unslash($_POST['ofp_biz_name'])) : '';
        $in['tagline']     = isset($_POST['ofp_tagline']) ? sanitize_text_field(wp_unslash($_POST['ofp_tagline'])) : '';
        $pos               = isset($_POST['ofp_position']) ? sanitize_key($_POST['ofp_position']) : 'br';
        $in['position']    = array_key_exists($pos, ofp_positions()) ? $pos : 'br';
        $accent            = isset($_POST['ofp_accent']) ? sanitize_hex_color(wp_unslash($_POST['ofp_accent'])) : '';
        $in['accent']      = $accent ? $accent : '#e8c96a';
        $in['draggable']   = !empty($_POST['ofp_draggable']) ? 1 : 0;
        $in['autohide']    = !empty($_POST['ofp_autohide']) ? 1 : 0;
        $in['smart_avoid'] = !empty($_POST['ofp_smart_avoid']) ? 1 : 0;
        $in['btn_label']   = isset($_POST['ofp_btn_label']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['ofp_btn_label']))) : 'OFFRE';
        $in['popup_note']  = isset($_POST['ofp_popup_note']) ? sanitize_text_field(wp_unslash($_POST['ofp_popup_note'])) : '';

        update_option('ofp_settings', $in);
        ofp_flash_set(ofp_t('Réglages enregistrés avec succès.', 'Settings saved successfully.'));
        wp_safe_redirect(admin_url('admin.php?page=offerpulse'));
        exit;
    }

    if ($act === 'save_offers') {
        $raw   = isset($_POST['ofp_offer']) && is_array($_POST['ofp_offer']) ? wp_unslash($_POST['ofp_offer']) : array();
        $clean = array();
        foreach ($raw as $row) {
            $img = isset($row['image']) ? esc_url_raw($row['image']) : '';
            if ($img === '') continue;
            $clean[] = array(
                'image'   => $img,
                'link'    => isset($row['link']) ? esc_url_raw($row['link']) : '',
                'expires' => isset($row['expires']) ? sanitize_text_field($row['expires']) : '',
            );
        }
        update_option('ofp_offers', $clean);
        ofp_flash_set(count($clean) > 0
            ? sprintf(ofp_t('%d offre(s) enregistrée(s) avec succès.', '%d offer(s) saved successfully.'), count($clean))
            : ofp_t('Aucune offre valide — les lignes sans image ont été ignorées.', 'No valid offers — rows without an image were ignored.'),
            count($clean) > 0 ? 'ok' : 'err');
        wp_safe_redirect(admin_url('admin.php?page=offerpulse'));
        exit;
    }

    if ($act === 'reset_all') {
        delete_option('ofp_settings');
        delete_option('ofp_offers');
        ofp_flash_set(ofp_t('Toutes les données OfferPulse ont été réinitialisées.', 'All OfferPulse data has been reset.'));
        wp_safe_redirect(admin_url('admin.php?page=offerpulse'));
        exit;
    }
}

/* ============================================================
   6. PAGE ADMIN
   ============================================================ */

function ofp_admin_page() {
    if (!current_user_can('manage_options')) return;

    $s      = ofp_settings();
    $offers = ofp_offers();
    $flash  = ofp_flash_get();

    $biz_default = $s['biz_name'] !== '' ? $s['biz_name'] : wp_strip_all_tags(get_bloginfo('name'));
    ?>
    <div class="wrap ofp-admin">
        <style>
        .ofp-admin h1{display:flex;align-items:center;gap:10px;}
        .ofp-logo{width:34px;height:34px;border-radius:9px;background:conic-gradient(from 210deg,#e8c96a,#b3541e,#3d2c0f,#e8c96a);display:inline-flex;align-items:center;justify-content:center;font-size:17px;box-shadow:0 0 18px rgba(232,201,106,.45);}
        .ofp-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:16px;}
        @media(max-width:1100px){.ofp-grid{grid-template-columns:1fr;}}
        .ofp-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);}
        .ofp-card h2{margin-top:0;display:flex;align-items:center;gap:8px;font-size:15px;}
        .ofp-field{margin-bottom:14px;}
        .ofp-field label{display:block;font-weight:600;margin-bottom:5px;}
        .ofp-field .desc{font-weight:400;color:#646970;font-size:12px;margin-top:2px;}
        .ofp-field input[type=text],.ofp-field input[type=url],.ofp-field input[type=date]{width:100%;}
        .ofp-switch{display:flex;align-items:flex-start;gap:10px;padding:9px 12px;background:#f6f7f7;border-radius:8px;margin-bottom:9px;}
        .ofp-switch input{margin-top:3px;}
        .ofp-offer-row{display:grid;grid-template-columns:minmax(0,2fr) minmax(0,2fr) 150px auto auto;gap:8px;align-items:center;padding:10px;border:1px solid #e0e0e2;border-radius:10px;margin-bottom:10px;background:#fafafa;}
        .ofp-offer-row img{max-height:44px;max-width:70px;border-radius:6px;display:block;}
        .ofp-preview-empty{color:#a7aaad;font-size:11px;}
        @media(max-width:782px){.ofp-offer-row{grid-template-columns:1fr 1fr;}}
        .ofp-flash{padding:12px 16px;border-radius:8px;margin-top:14px;font-weight:600;}
        .ofp-flash.ok{background:#edfaef;border-inline-start:4px solid #00a32a;}
        .ofp-flash.err{background:#fcf0f1;border-inline-start:4px solid #d63638;}
        </style>

        <h1><span class="ofp-logo">⚡</span> OfferPulse <span style="font-size:12px;color:#8c8f94;font-weight:400;">v<?php echo esc_html(OFP_VERSION); ?></span></h1>

        <?php if ($flash) : ?>
            <div class="ofp-flash <?php echo esc_attr($flash['type']); ?>"><?php echo esc_html($flash['msg']); ?></div>
        <?php endif; ?>

        <form method="post">
            <?php wp_nonce_field('ofp_save', 'ofp_nonce'); ?>

            <input type="hidden" name="ofp_action" value="save_settings">
            <div class="ofp-grid">

                <div class="ofp-card">
                    <h2>🏢 <?php echo esc_html(ofp_t('Votre marque', 'Your brand')); ?></h2>
                    <div class="ofp-field">
                        <label><?php echo esc_html(ofp_t('Nom du site / entreprise', 'Site / business name')); ?></label>
                        <input type="text" name="ofp_biz_name" value="<?php echo esc_attr($biz_default); ?>">
                        <p class="desc"><?php echo esc_html(ofp_t('Affiché dans le titre du popup (« Offres de … ») et dans le menu admin.', 'Shown in the popup title (“Offers from …”) and in the admin menu.')); ?></p>
                    </div>
                    <div class="ofp-field">
                        <label><?php echo esc_html(ofp_t('Sous-titre du popup', 'Popup subtitle')); ?> <em>(<?php echo esc_html(ofp_t('facultatif', 'optional')); ?>)</em></label>
                        <input type="text" name="ofp_tagline" value="<?php echo esc_attr($s['tagline']); ?>" placeholder="<?php echo esc_attr(ofp_t('ex : Profitez vite de nos promotions !', 'e.g. Enjoy our special deals now!')); ?>">
                    </div>
                    <div class="ofp-field">
                        <label><?php echo esc_html(ofp_t("Mot sur l'icône", 'Icon word')); ?></label>
                        <input type="text" name="ofp_btn_label" maxlength="12" value="<?php echo esc_attr($s['btn_label']); ?>">
                        <p class="desc"><?php echo esc_html(ofp_t("Texte court affiché sous l'icône flottante (ex : OFFRE, PROMO, SOLDE).", "Short text shown under the floating icon (e.g. DEAL, SALE, OFFER).")); ?></p>
                    </div>
                    <div class="ofp-field">
                        <label><?php echo esc_html(ofp_t('Note bas de popup', 'Popup footer note')); ?> <em>(<?php echo esc_html(ofp_t('facultatif', 'optional')); ?>)</em></label>
                        <input type="text" name="ofp_popup_note" value="<?php echo esc_attr($s['popup_note']); ?>" placeholder="<?php echo esc_attr(ofp_t('ex : Contactez-nous pour en profiter', 'e.g. Contact us to take advantage')); ?>">
                    </div>
                </div>

                <div class="ofp-card">
                    <h2>🎛️ <?php echo esc_html(ofp_t('Apparence &amp; comportement', 'Appearance &amp; behaviour')); ?></h2>
                    <div class="ofp-field">
                        <label><?php echo esc_html(ofp_t("Position de l'icône flottante", 'Floating icon position')); ?></label>
                        <select name="ofp_position">
                            <?php foreach (ofp_positions() as $k => $lbl) : ?>
                                <option value="<?php echo esc_attr($k); ?>" <?php selected($s['position'], $k); ?>><?php echo esc_html($lbl); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="desc"><?php echo esc_html(ofp_t("Le visiteur pourra aussi la glisser où il veut si l'option ci-dessous est active.", 'The visitor can also drag it anywhere if the option below is enabled.')); ?></p>
                    </div>
                    <div class="ofp-field">
                        <label><?php echo esc_html(ofp_t("Couleur d'accent", 'Accent color')); ?></label>
                        <input type="color" name="ofp_accent" value="<?php echo esc_attr($s['accent']); ?>" style="width:64px;height:36px;padding:2px;">
                    </div>
                    <label class="ofp-switch"><input type="checkbox" name="ofp_draggable" value="1" <?php checked($s['draggable'], 1); ?>> <span><b><?php echo esc_html(ofp_t('Icône déplaçable', 'Draggable icon')); ?></b> — <?php echo esc_html(ofp_t("le visiteur peut la faire glisser ; sa position est mémorisée.", 'the visitor can drag it; its position is remembered.')); ?></span></label>
                    <label class="ofp-switch"><input type="checkbox" name="ofp_autohide" value="1" <?php checked($s['autohide'], 1); ?>> <span><b><?php echo esc_html(ofp_t('Masquer pendant le défilement', 'Hide while scrolling')); ?></b> — <?php echo esc_html(ofp_t("l'icône s'estompe quand on descend, revient quand on remonte.", 'the icon fades out when scrolling down, comes back when scrolling up.')); ?></span></label>
                    <label class="ofp-switch"><input type="checkbox" name="ofp_smart_avoid" value="1" <?php checked($s['smart_avoid'], 1); ?>> <span><b><?php echo esc_html(ofp_t('Anti-collision intelligente', 'Smart anti-collision')); ?></b> — <?php echo esc_html(ofp_t("se replace automatiquement au-dessus des autres widgets flottants (chats, boutons retour haut…).", 'automatically repositions above other floating widgets (chats, back-to-top buttons…).')); ?></span></label>
                </div>
            </div>
            <p style="margin-top:18px;">
                <button type="submit" class="button button-primary button-hero">💾 <?php echo esc_html(ofp_t('Enregistrer les réglages', 'Save settings')); ?></button>
            </p>
        </form>

        <form method="post" style="margin-top:26px;">
            <?php wp_nonce_field('ofp_save', 'ofp_nonce'); ?>
            <input type="hidden" name="ofp_action" value="save_offers">

            <div class="ofp-card">
                <h2>🎁 <?php echo esc_html(ofp_t('Vos offres', 'Your offers')); ?> <span style="font-weight:400;color:#8c8f94;font-size:12px;">— <?php echo esc_html(ofp_t('illimité, expirent automatiquement à la date choisie', 'unlimited, expire automatically on the chosen date')); ?></span></h2>
                <div id="ofp-rows">
                    <?php foreach ($offers as $i => $o) : ?>
                        <div class="ofp-offer-row">
                            <div>
                                <input type="url" name="ofp_offer[<?php echo $i; ?>][image]" value="<?php echo esc_attr($o['image']); ?>" placeholder="<?php echo esc_attr(ofp_t("URL de l'image", 'Image URL')); ?>">
                            </div>
                            <div>
                                <input type="url" name="ofp_offer[<?php echo $i; ?>][link]" value="<?php echo esc_attr($o['link']); ?>" placeholder="<?php echo esc_attr(ofp_t('https://lien-de-l-offre (facultatif)', 'https://offer-link (optional)')); ?>">
                            </div>
                            <div>
                                <input type="date" name="ofp_offer[<?php echo $i; ?>][expires]" value="<?php echo esc_attr($o['expires']); ?>">
                            </div>
                            <div>
                                <img src="<?php echo esc_url($o['image']); ?>" alt="" onerror="this.style.display='none'">
                            </div>
                            <div>
                                <button type="button" class="button ofp-pick">🖼️</button>
                                <button type="button" class="button ofp-del" title="<?php echo esc_attr(ofp_t('Supprimer', 'Delete')); ?>">🗑️</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p>
                    <button type="button" class="button" id="ofp-add">➕ <?php echo esc_html(ofp_t('Ajouter une offre', 'Add an offer')); ?></button>
                    <button type="submit" class="button button-primary">💾 <?php echo esc_html(ofp_t('Enregistrer les offres', 'Save offers')); ?></button>
                </p>
                <p class="description"><?php echo esc_html(ofp_t("🖼️ = choisir une image dans la bibliothèque de médias. Laissez le lien vide pour une offre sans redirection.", "🖼️ = pick an image from the media library. Leave the link empty for an offer without redirection.")); ?></p>
            </div>
        </form>

        <form method="post" onsubmit="return confirm('<?php echo esc_js(ofp_t('Réinitialiser TOUTES les données OfferPulse ?', 'Reset ALL OfferPulse data?')); ?>');">
            <?php wp_nonce_field('ofp_save', 'ofp_nonce'); ?>
            <input type="hidden" name="ofp_action" value="reset_all">
            <p style="margin-top:22px;"><button type="submit" class="button-link" style="color:#b32d2e;text-decoration:none;">♻️ <?php echo esc_html(ofp_t('Réinitialiser complètement le plugin', 'Completely reset the plugin')); ?></button></p>
        </form>
    </div>

    <script>
    (function () {
        var idx = 1000;
        var T = {
            imgUrl: '<?php echo esc_js(ofp_t("URL de l'image", 'Image URL')); ?>',
            optional: '<?php echo esc_js(ofp_t('facultatif', 'optional')); ?>',
            preview: '<?php echo esc_js(ofp_t('aperçu ici', 'preview here')); ?>',
            del: '<?php echo esc_js(ofp_t('Supprimer', 'Delete')); ?>',
            chooseImg: '<?php echo esc_js(ofp_t('Choisir une image', 'Choose an image')); ?>'
        };

        function row(i) {
            var d = document.createElement('div');
            d.className = 'ofp-offer-row';
            d.innerHTML =
                '<div><input type="url" name="ofp_offer[' + i + '][image]" placeholder="' + T.imgUrl + '"></div>' +
                '<div><input type="url" name="ofp_offer[' + i + '][link]" placeholder="https:// (' + T.optional + ')"></div>' +
                '<div><input type="date" name="ofp_offer[' + i + '][expires]"></div>' +
                '<div><span class="ofp-preview-empty">' + T.preview + '</span></div>' +
                '<div><button type="button" class="button ofp-pick">🖼️</button> ' +
                '<button type="button" class="button ofp-del" title="' + T.del + '">🗑️</button></div>';
            return d;
        }

        function frame(input) {
            if (!window.wp || !wp.media) {
                var u = window.prompt(T.imgUrl + ' :');
                if (u) {
                    input.value = u;
                    input.dispatchEvent(new Event('change'));
                }
                return;
            }
            var f = wp.media({ title: T.chooseImg, multiple: false, library: { type: 'image' } });
            f.on('select', function () {
                var a = f.state().get('selection').first().toJSON();
                input.value = (a.sizes && a.sizes.large) ? a.sizes.large.url : a.url;
                input.dispatchEvent(new Event('change'));
            });
            f.open();
        }

        document.addEventListener('click', function (e) {
            if (e.target.classList && e.target.classList.contains('ofp-del')) {
                e.target.closest('.ofp-offer-row').remove();
            }
            if (e.target.classList && e.target.classList.contains('ofp-pick')) {
                var r = e.target.closest('.ofp-offer-row');
                frame(r.querySelector('input[type=url]'));
            }
            if (e.target.id === 'ofp-add') {
                document.getElementById('ofp-rows').appendChild(row(idx++));
            }
        });

        document.addEventListener('change', function (e) {
            if (e.target && e.target.name && e.target.name.indexOf('[image]') !== -1) {
                var prev = e.target.closest('.ofp-offer-row').querySelector('div:nth-child(4)');
                if (prev && e.target.value) {
                    prev.innerHTML = '<img src="' + e.target.value + '" alt="">';
                }
            }
        });
    })();
    </script>
    <?php
}

add_action('admin_enqueue_scripts', 'ofp_admin_media');

function ofp_admin_media($hook) {
    if ($hook !== 'toplevel_page_offerpulse') return;
    wp_enqueue_media();
}

/* ============================================================
   7. FRONTEND — ICÔNE FLOTTANTE + POPUP
   ============================================================ */

add_action('wp_footer', 'ofp_render_frontend', 99);

function ofp_render_frontend() {
    $s      = ofp_settings();
    $today  = current_time('Y-m-d');
    $valid  = array();

    foreach (ofp_offers() as $o) {
        if (empty($o['image'])) continue;
        if (!empty($o['expires']) && strtotime($o['expires']) < strtotime($today)) continue;
        $valid[] = $o;
    }

    if (empty($valid)) return;

    $biz     = $s['biz_name'] !== '' ? $s['biz_name'] : wp_strip_all_tags(get_bloginfo('name'));
    $label   = $s['btn_label'] !== '' ? $s['btn_label'] : 'OFFRE';
    $count   = count($valid);
    $pos_map = array('br' => array('right','bottom'), 'bl' => array('left','bottom'), 'bc' => array('center','bottom'));

    $css_var = '--ofp-accent:' . esc_attr($s['accent']) . ';';
    ?>
    <style id="ofp-css">
    :root{<?php echo $css_var; ?>--ofp-glow:color-mix(in srgb,var(--ofp-accent) 55%,transparent);}
    .ofp-root{position:fixed;z-index:99990;pointer-events:none;}
    .ofp-pos-br{right:max(18px,env(safe-area-inset-right));bottom:max(18px,env(safe-area-inset-bottom));}
    .ofp-pos-bl{left:max(18px,env(safe-area-inset-left));bottom:max(18px,env(safe-area-inset-bottom));}
    .ofp-pos-bc{left:50%;transform:translateX(-50%);bottom:max(18px,env(safe-area-inset-bottom));}
    .ofp-btn{pointer-events:auto;position:relative;width:74px;height:86px;cursor:pointer;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;touch-action:none;filter:drop-shadow(0 6px 22px var(--ofp-glow));transition:opacity .35s,transform .35s;opacity:.92;}
    .ofp-btn:hover{opacity:1;transform:translateY(-3px) scale(1.03);}
    .ofp-btn:focus-visible{outline:2px solid var(--ofp-accent);outline-offset:4px;border-radius:50%;}
    .ofp-orb{position:relative;width:74px;height:74px;border-radius:50%;
        background:radial-gradient(circle at 32% 28%,rgba(255,255,255,.28),transparent 42%),radial-gradient(circle at 68% 76%,var(--ofp-glow),transparent 58%),linear-gradient(160deg,#141a33,#232c52 62%,#10142a);
        border:1px solid color-mix(in srgb,var(--ofp-accent) 65%,#ffffff22);
        box-shadow:0 0 0 3px color-mix(in srgb,var(--ofp-accent) 22%,transparent),0 0 26px var(--ofp-glow);
        overflow:hidden;}
    .ofp-orb::before{content:'';position:absolute;inset:-40%;background:conic-gradient(from 0deg,transparent 0deg,color-mix(in srgb,var(--ofp-accent) 85%,#fff) 42deg,transparent 88deg,transparent 240deg,color-mix(in srgb,var(--ofp-accent) 45%,#fff) 300deg,transparent 350deg);animation:ofp-spin 7s linear infinite;}
    .ofp-orb::after{content:'';position:absolute;inset:3px;border-radius:50%;background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.14),transparent 45%),linear-gradient(165deg,#161d3a,#0d1226);border:1px solid rgba(255,255,255,.06);}
    .ofp-glyph{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;z-index:2;}
    .ofp-glyph svg{width:30px;height:30px;fill:none;stroke:var(--ofp-accent);stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 0 6px var(--ofp-glow));animation:ofp-bob 3.2s ease-in-out infinite;}
    .ofp-badge{position:absolute;top:-2px;inset-inline-end:-2px;min-width:21px;height:21px;padding:0 5px;border-radius:999px;background:linear-gradient(135deg,#ff5f6d,#c81e3a);color:#fff;font-size:11px;font-weight:800;line-height:21px;text-align:center;box-shadow:0 2px 10px rgba(200,30,58,.65);border:2px solid #0d1226;z-index:3;}
    .ofp-tag{margin-top:5px;text-align:center;font-size:9.5px;font-weight:800;letter-spacing:2.5px;color:#eef2ff;text-shadow:0 1px 4px rgba(0,0,0,.85);}
    @keyframes ofp-spin{to{transform:rotate(360deg);}}
    @keyframes ofp-bob{0%,100%{transform:translateY(0);}50%{transform:translateY(-2.5px);}}
    .ofp-halo{position:absolute;inset:-7px;border-radius:50%;border:1.5px solid var(--ofp-accent);opacity:0;animation:ofp-ping 2.6s cubic-bezier(.2,.6,.35,1) infinite;pointer-events:none;}
    @keyframes ofp-ping{0%{transform:scale(.82);opacity:.75;}70%{transform:scale(1.22);opacity:0;}100%{opacity:0;}}
    .ofp-btn.ofp-fade{opacity:0;pointer-events:none;transform:translateY(14px) scale(.9);}
    .ofp-pop{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(4,7,18,.72);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);opacity:0;visibility:hidden;transition:.3s ease;}
    .ofp-pop.ofp-open{opacity:1;visibility:visible;}
    .ofp-panel{position:relative;width:min(560px,94vw);max-height:min(84vh,720px);overflow:auto;border-radius:22px;padding:30px 26px 24px;
        background:linear-gradient(168deg,#131937 0%,#1a2144 55%,#12162b 100%);
        border:1px solid color-mix(in srgb,var(--ofp-accent) 40%,#ffffff14);
        box-shadow:0 30px 90px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.03) inset,0 0 60px var(--ofp-glow);
        transform:translateY(26px) scale(.95);transition:.35s cubic-bezier(.2,.9,.3,1.15);scrollbar-width:thin;scrollbar-color:var(--ofp-accent) transparent;}
    .ofp-pop.ofp-open .ofp-panel{transform:none;}
    .ofp-panel::-webkit-scrollbar{width:8px;}
    .ofp-panel::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--ofp-accent) 55%,transparent);border-radius:99px;}
    .ofp-close{position:absolute;top:13px;inset-inline-end:13px;width:36px;height:36px;border-radius:50%;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.05);color:#dfe6ff;font-size:19px;cursor:pointer;transition:.25s;line-height:1;}
    .ofp-close:hover{background:var(--ofp-accent);color:#10131f;border-color:var(--ofp-accent);transform:rotate(90deg);}
    .ofp-head{text-align:center;margin-bottom:20px;}
    .ofp-kicker{display:inline-flex;align-items:center;gap:7px;font-size:10px;font-weight:800;letter-spacing:3px;color:var(--ofp-accent);text-transform:uppercase;margin-bottom:9px;}
    .ofp-kicker::before,.ofp-kicker::after{content:'';height:1px;width:26px;background:linear-gradient(90deg,transparent,var(--ofp-accent));}
    .ofp-kicker::after{transform:scaleX(-1);}
    .ofp-title{font-size:clamp(19px,4vw,25px);font-weight:800;color:#f4f6ff;letter-spacing:.4px;line-height:1.25;margin:0;}
    .ofp-title em{font-style:normal;background:linear-gradient(120deg,var(--ofp-accent),#fff8dd 55%,var(--ofp-accent));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;}
    .ofp-sub{margin-top:7px;font-size:12.5px;color:#93a0c6;}
    .ofp-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));gap:16px;}
    .ofp-item{position:relative;display:block;border-radius:16px;overflow:hidden;border:1px solid rgba(255,255,255,.09);background:#0d1226;text-decoration:none;transition:.3s;transform:translateZ(0);}
    .ofp-item:hover{transform:translateY(-5px);border-color:color-mix(in srgb,var(--ofp-accent) 60%,transparent);box-shadow:0 16px 40px rgba(0,0,0,.5),0 0 24px var(--ofp-glow);}
    .ofp-item img{display:block;width:100%;aspect-ratio:4/3;object-fit:cover;}
    .ofp-count{position:absolute;top:10px;inset-inline-start:10px;font-size:10.5px;font-weight:800;letter-spacing:.6px;color:#10131f;background:linear-gradient(135deg,#ffe9a8,var(--ofp-accent));padding:4px 9px;border-radius:999px;box-shadow:0 3px 12px rgba(0,0,0,.4);}
    .ofp-count.ofp-last{background:linear-gradient(135deg,#ff8f6b,#ff4d67);color:#fff;animation:ofp-blink 1.4s ease-in-out infinite;}
    @keyframes ofp-blink{50%{opacity:.72;}}
    .ofp-go{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:11px 14px;font-size:12px;font-weight:700;color:#e9edff;background:rgba(255,255,255,.035);border-top:1px solid rgba(255,255,255,.07);}
    .ofp-go span:last-child{color:var(--ofp-accent);transition:.25s;}
    .ofp-item:hover .ofp-go span:last-child{transform:translateX(4px);}
    [dir="rtl"] .ofp-item:hover .ofp-go span:last-child{transform:scaleX(-1);}
    .ofp-note{margin-top:18px;text-align:center;font-size:12px;color:#8fa0cc;}
    .ofp-empty{text-align:center;padding:44px 10px;color:#aebbe4;font-size:14px;line-height:1.8;}
    .ofp-empty b{color:var(--ofp-accent);}
    @media(max-width:520px){.ofp-btn{width:60px;height:70px;}.ofp-orb{width:60px;height:60px;}.ofp-glyph svg{width:25px;height:25px;}.ofp-tag{font-size:8.5px;letter-spacing:1.8px;}}
    @media(prefers-reduced-motion:reduce){.ofp-orb::before,.ofp-glyph svg,.ofp-halo,.ofp-count.ofp-last{animation:none;}}
    </style>

    <div class="ofp-root ofp-pos-<?php echo esc_attr($s['position']); ?>" id="ofpRoot">
        <div class="ofp-btn" id="ofpBtn" role="button" tabindex="0" aria-haspopup="dialog" aria-expanded="false"
             aria-label="<?php echo esc_attr(sprintf(ofp_t('Offres %s', 'Offers — %s'), $biz)); ?>"
             data-drag="<?php echo (int) $s['draggable']; ?>"
             data-autohide="<?php echo (int) $s['autohide']; ?>"
             data-smart="<?php echo (int) $s['smart_avoid']; ?>">
            <span class="ofp-halo"></span>
            <span class="ofp-orb">
                <span class="ofp-glyph">
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M20 12v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2"/>
                        <path d="M12 3v9"/><path d="m8 8 4 4 4-4"/>
                    </svg>
                </span>
            </span>
            <?php if ($count > 1) : ?><span class="ofp-badge"><?php echo (int) $count; ?></span><?php endif; ?>
            <span class="ofp-tag"><?php echo esc_html($label); ?></span>
        </div>
    </div>

    <div class="ofp-pop" id="ofpPop" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr(sprintf(ofp_t('Offres de %s', 'Offers from %s'), $biz)); ?>">
        <div class="ofp-panel" id="ofpPanel">
            <button type="button" class="ofp-close" id="ofpClose" aria-label="<?php echo esc_attr(ofp_t('Fermer', 'Close')); ?>">×</button>
            <div class="ofp-head">
                <span class="ofp-kicker"><?php echo esc_html($biz); ?></span>
                <h2 class="ofp-title"><?php echo wp_kses_post(ofp_t('Offres <em>spéciales</em> du moment', 'Special <em>offers</em> on now')); ?></h2>
                <?php if ($s['tagline'] !== '') : ?><p class="ofp-sub"><?php echo esc_html($s['tagline']); ?></p><?php endif; ?>
            </div>
            <div class="ofp-grid">
                <?php foreach ($valid as $o) :
                    $days  = !empty($o['expires']) ? (int) floor((strtotime($o['expires']) - strtotime($today)) / 86400) : null;
                    $is_a  = $o['link'] !== '';
                    $open  = $is_a ? '<a href="' . esc_url($o['link']) . '" target="_blank" rel="noopener" class="ofp-item">' : '<div class="ofp-item">';
                    $close = $is_a ? '</a>' : '</div>';
                ?>
                    <?php echo $open; ?>
                        <img src="<?php echo esc_url($o['image']); ?>" alt="<?php echo esc_attr(sprintf(ofp_t('Offre — %s', 'Offer — %s'), $biz)); ?>" loading="lazy">
                        <?php if ($days !== null) : ?>
                            <span class="ofp-count<?php echo $days <= 3 ? ' ofp-last' : ''; ?>">
                                <?php echo $days > 0 ? sprintf(ofp_t('⏳ J-%d', '⏳ D-%d'), $days) : ofp_t('🔥 Dernier jour', '🔥 Last day'); ?>
                            </span>
                        <?php endif; ?>
                        <div class="ofp-go"><span><?php echo esc_html(ofp_t("Découvrir l'offre", 'View offer')); ?></span><span>➜</span></div>
                    <?php echo $close; ?>
                <?php endforeach; ?>
            </div>
            <?php if ($s['popup_note'] !== '') : ?><p class="ofp-note"><?php echo esc_html($s['popup_note']); ?></p><?php endif; ?>
        </div>
    </div>

    <script id="ofp-js">
    (function () {
        var root = document.getElementById('ofpRoot'),
            btn  = document.getElementById('ofpBtn'),
            pop  = document.getElementById('ofpPop'),
            panel= document.getElementById('ofpPanel'),
            close= document.getElementById('ofpClose');
        if (!root || !btn || !pop) return;

        var DRAG  = btn.getAttribute('data-drag')  === '1',
            HIDE  = btn.getAttribute('data-autohide')=== '1',
            SMART = btn.getAttribute('data-smart') === '1',
            KEY   = 'ofpPos:' + location.host,
            moved = false;

        /* ---- Restauration position personnalisée ---- */
        try {
            var saved = JSON.parse(localStorage.getItem(KEY) || 'null');
            if (saved && typeof saved.x === 'number') place(saved.x, saved.y, true);
        } catch (e) {}

        function clamp(x, y) {
            var w = btn.offsetWidth, h = btn.offsetHeight;
            return {
                x: Math.min(Math.max(4, x), innerWidth  - w - 4),
                y: Math.min(Math.max(4, y), innerHeight - h - 4)
            };
        }
        function place(x, y, skipSmart) {
            var c = clamp(x, y);
            root.style.left = c.x + 'px';
            root.style.top  = c.y + 'px';
            root.style.right = 'auto'; root.style.bottom = 'auto';
            root.style.transform = 'none';
            if (!skipSmart && SMART) setTimeout(avoid, 60);
        }

        /* ---- Anti-collision : s'empile au-dessus des widgets fixes voisins ---- */
        function avoid() {
            if (!SMART) return;
            var r = btn.getBoundingClientRect();
            if (!r.width) return;
            var others = [];
            document.querySelectorAll('body *').forEach(function (el) {
                if (root.contains(el) || el.closest('.ofp-pop')) return;
                var cs = getComputedStyle(el);
                if (cs.position !== 'fixed' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) return;
                if (el.offsetWidth < 20 || el.offsetHeight < 20) return;
                var o = el.getBoundingClientRect(), ix = !(o.right < r.left - 6 || o.left > r.right + 6 || o.bottom < r.top - 6 || o.top > r.bottom + 6);
                if (ix && o.width < innerWidth * .9) others.push(o);
            });
            if (!others.length) return;
            var x = r.left, y = r.top;
            others.sort(function (a, b) { return b.top - a.top; }).some(function (o) {
                if (Math.abs(o.left + o.width / 2 - (x + r.width / 2)) < Math.max(o.width, r.width)) {
                    y = o.top - r.height - 10;
                    return true;
                }
                return false;
            });
            place(x, y, true);
        }

        /* ---- Glisser-déposer ---- */
        var sx, sy, bx, by, dragging = false;
        btn.addEventListener('pointerdown', function (e) {
            if (!DRAG || e.button) return;
            dragging = true; moved = false;
            sx = e.clientX; sy = e.clientY;
            var r = btn.getBoundingClientRect(); bx = r.left; by = r.top;
            btn.setPointerCapture(e.pointerId);
        });
        btn.addEventListener('pointermove', function (e) {
            if (!dragging) return;
            var dx = e.clientX - sx, dy = e.clientY - sy;
            if (Math.abs(dx) + Math.abs(dy) > 6) moved = true;
            if (moved) place(bx + dx, by + dy, true);
        });
        btn.addEventListener('pointerup', function (e) {
            if (!dragging) return;
            dragging = false;
            if (moved) {
                var r = btn.getBoundingClientRect();
                try { localStorage.setItem(KEY, JSON.stringify({ x: r.left, y: r.top })); } catch (err) {}
                avoid();
            } else {
                open();
            }
        });
        btn.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
        });

        /* ---- Masquage au défilement ---- */
        var lastY = scrollY, ticking = false;
        addEventListener('scroll', function () {
            if (ticking) return;
            ticking = true;
            requestAnimationFrame(function () {
                if (HIDE) btn.classList.toggle('ofp-fade', scrollY - lastY > 8);
                lastY = scrollY; ticking = false;
            });
        }, { passive: true });

        /* ---- Popup ---- */
        function open() {
            pop.classList.add('ofp-open');
            btn.setAttribute('aria-expanded', 'true');
            document.body.style.overflow = 'hidden';
            setTimeout(function(){ close.focus(); }, 250);
        }
        function shut() {
            pop.classList.remove('ofp-open');
            btn.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
            btn.focus();
        }
        close.addEventListener('click', shut);
        pop.addEventListener('click', function (e) { if (e.target === pop) shut(); });
        addEventListener('keydown', function (e) { if (e.key === 'Escape' && pop.classList.contains('ofp-open')) shut(); });

        /* ---- Recalage après resize ---- */
        var rt;
        addEventListener('resize', function () {
            clearTimeout(rt);
            rt = setTimeout(function () {
                var r = btn.getBoundingClientRect();
                place(r.left, r.top, true);
                avoid();
            }, 150);
        });

        setTimeout(avoid, 400);
    })();
    </script>
    <?php
}

/* ============================================================
   8. LIEN RÉGLAGES SUR LA PAGE EXTENSIONS
   ============================================================ */

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    array_unshift($links, '<a href="' . admin_url('admin.php?page=offerpulse') . '">' . ofp_t('Réglages', 'Settings') . '</a>');
    return $links;
});
